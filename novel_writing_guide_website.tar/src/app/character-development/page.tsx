import Layout from '@/components/ui/layout';
import { Section, Quote, TipBox, Exercise, Sidebar } from '@/components/ui/content-blocks';

export default function Page() {
  const sidebarLinks = [
    { title: 'Character Fundamentals', href: '#character-fundamentals' },
    { title: 'Creating Memorable Characters', href: '#creating-memorable-characters' },
    { title: 'Character Arcs and Development', href: '#character-arcs-and-development' },
    { title: 'Character Relationships', href: '#character-relationships' },
    { title: 'Character Voice and Dialogue', href: '#character-voice-and-dialogue' }
  ];

  return (
    <Layout>
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
        <div className="lg:col-span-3">
          <h1 className="text-4xl font-bold text-slate-900 mb-6">Character Development</h1>
          
          <Section title="Character Fundamentals">
            <p>
              Characters are the heart of your novel. Readers may be drawn in by an intriguing premise or setting, but they stay for the characters—the complex, compelling individuals whose journeys they become invested in. Strong character development is essential to creating a novel that resonates with readers.
            </p>
            
            <p>
              At its core, character development is about creating fictional people who feel authentic and three-dimensional. These characters should have distinct personalities, motivations, flaws, and growth trajectories that drive your story forward and engage your readers emotionally.
            </p>
            
            <h3 className="text-xl font-semibold mt-6 mb-3">The Role of Characters in Fiction</h3>
            
            <p>
              Characters serve multiple functions in your novel:
            </p>
            
            <ul className="list-disc pl-6 space-y-2 my-4">
              <li>
                <strong>Drive the plot:</strong> Characters' decisions, desires, and actions should propel your story forward.
              </li>
              <li>
                <strong>Embody themes:</strong> Characters often represent or explore the central themes of your novel.
              </li>
              <li>
                <strong>Create emotional connection:</strong> Characters are the primary vehicle through which readers experience your story emotionally.
              </li>
              <li>
                <strong>Provide perspective:</strong> Characters offer different viewpoints on the events and world of your novel.
              </li>
              <li>
                <strong>Generate conflict:</strong> Characters' opposing goals and values create the tension that sustains your narrative.
              </li>
            </ul>
            
            <Quote 
              text="Plot is what happens. Character is to whom it happens. And what happens affects your characters, just as your characters affect what happens."
              author="Elizabeth George"
            />
            
            <h3 className="text-xl font-semibold mt-6 mb-3">Types of Characters</h3>
            
            <p>
              Not all characters play equal roles in your story. Understanding different character types helps you allocate your development efforts appropriately:
            </p>
            
            <ul className="list-disc pl-6 space-y-2 my-4">
              <li>
                <strong>Protagonist:</strong> The main character whose journey forms the central narrative. Readers experience much of the story through their perspective.
              </li>
              <li>
                <strong>Antagonist:</strong> The character (or force) that opposes the protagonist and creates the central conflict.
              </li>
              <li>
                <strong>Supporting characters:</strong> Secondary characters who play significant roles in the story and often have their own arcs.
              </li>
              <li>
                <strong>Minor characters:</strong> Characters who appear briefly but serve specific functions in the narrative.
              </li>
              <li>
                <strong>Foils:</strong> Characters who contrast with another character (often the protagonist) to highlight particular qualities.
              </li>
            </ul>
            
            <p>
              While your protagonist will typically receive the most development, all characters should feel like real people with lives that extend beyond their role in your story.
            </p>
          </Section>
          
          <Section title="Creating Memorable Characters">
            <p>
              Memorable characters stay with readers long after they've finished your novel. These characters feel authentic, distinctive, and compelling—like real people readers have come to know intimately.
            </p>
            
            <h3 className="text-xl font-semibold mt-6 mb-3">Character Dimensions</h3>
            
            <p>
              Well-developed characters have multiple dimensions:
            </p>
            
            <ul className="list-disc pl-6 space-y-2 my-4">
              <li>
                <strong>External traits:</strong> Physical appearance, mannerisms, speech patterns, and behaviors that others can observe.
              </li>
              <li>
                <strong>Internal traits:</strong> Thoughts, feelings, values, fears, and desires that may not be immediately visible to others.
              </li>
              <li>
                <strong>Background:</strong> Personal history, cultural context, and formative experiences that shape who they are.
              </li>
              <li>
                <strong>Relationships:</strong> Connections to other characters that reveal different facets of their personality.
              </li>
              <li>
                <strong>Contradictions:</strong> Inconsistencies and complexities that make them feel human rather than one-dimensional.
              </li>
            </ul>
            
            <TipBox title="Show, Don't Tell">
              <p>
                When introducing character traits, look for opportunities to demonstrate them through action, dialogue, and interaction rather than simply stating them. For example:
              </p>
              <ul className="list-disc pl-5 space-y-1 mt-2">
                <li><strong>Telling:</strong> "Maria was extremely organized and detail-oriented."</li>
                <li><strong>Showing:</strong> "Maria's desk contained three perfectly aligned stacks of color-coded folders. Her calendar was marked with different highlighters for each project, with reminder notes placed precisely three days before each deadline."</li>
              </ul>
            </TipBox>
            
            <h3 className="text-xl font-semibold mt-6 mb-3">Character Development Techniques</h3>
            
            <p>
              These approaches can help you create fully realized characters:
            </p>
            
            <h4 className="text-lg font-medium mt-4 mb-2">1. Character Profiles</h4>
            
            <p>
              Create detailed profiles for your main characters that include:
            </p>
            
            <ul className="list-disc pl-6 space-y-1 my-2">
              <li>Basic information (name, age, occupation, physical description)</li>
              <li>Personality traits and temperament</li>
              <li>Core values and beliefs</li>
              <li>Strengths and weaknesses</li>
              <li>Fears and desires</li>
              <li>Background and formative experiences</li>
              <li>Habits, hobbies, and interests</li>
              <li>Relationships with other characters</li>
            </ul>
            
            <h4 className="text-lg font-medium mt-4 mb-2">2. Character Interviews</h4>
            
            <p>
              Interview your characters as if they were real people. Ask them questions about their lives, opinions, and experiences. This exercise often reveals unexpected aspects of your characters and helps you develop their unique voices.
            </p>
            
            <h4 className="text-lg font-medium mt-4 mb-2">3. Character Backstory</h4>
            
            <p>
              Write scenes from your character's past that shaped who they are, even if these scenes won't appear in your novel. Understanding these formative experiences helps you write consistent, motivated characters.
            </p>
            
            <h4 className="text-lg font-medium mt-4 mb-2">4. Character Motivation</h4>
            
            <p>
              Identify what drives each character at different levels:
            </p>
            
            <ul className="list-disc pl-6 space-y-1 my-2">
              <li><strong>External goal:</strong> What they consciously want to achieve</li>
              <li><strong>Internal need:</strong> What they unconsciously need (often different from what they want)</li>
              <li><strong>Core motivation:</strong> The fundamental why behind their actions</li>
            </ul>
            
            <Exercise title="Character Development Exercise">
              <p>Choose one of your main characters and answer these questions:</p>
              <ol className="list-decimal pl-6 space-y-1 mt-2">
                <li>What does this character want more than anything? Why?</li>
                <li>What is this character's greatest fear? How does it influence their behavior?</li>
                <li>What contradiction exists in this character's personality?</li>
                <li>What secret does this character keep from others?</li>
                <li>What would this character do if they found a large sum of money?</li>
                <li>How does this character behave differently with different people in their life?</li>
              </ol>
              <p className="mt-3">
                Use your answers to add depth to your character's portrayal in your novel.
              </p>
            </Exercise>
          </Section>
          
          <Section title="Character Arcs and Development">
            <p>
              A character arc traces the internal journey and transformation of a character throughout your novel. Well-crafted character arcs create emotional investment and satisfaction for readers as they witness meaningful change.
            </p>
            
            <h3 className="text-xl font-semibold mt-6 mb-3">Types of Character Arcs</h3>
            
            <p>
              Characters can undergo various types of transformation:
            </p>
            
            <ul className="list-disc pl-6 space-y-2 my-4">
              <li>
                <strong>Positive arc:</strong> The character overcomes flaws or limitations to become a better or more complete person.
              </li>
              <li>
                <strong>Negative arc:</strong> The character declines morally or spiritually, often due to fatal flaws or corrupting circumstances.
              </li>
              <li>
                <strong>Flat arc:</strong> The character remains fundamentally unchanged but affects change in others or proves the validity of their beliefs through trials.
              </li>
              <li>
                <strong>Circular arc:</strong> The character changes but ultimately returns to their starting point, though with new perspective.
              </li>
              <li>
                <strong>Incremental arc:</strong> The character changes gradually through a series of small realizations rather than one dramatic transformation.
              </li>
            </ul>
            
            <h3 className="text-xl font-semibold mt-6 mb-3">Structuring Character Arcs</h3>
            
            <p>
              A typical character arc progresses through these stages:
            </p>
            
            <ol className="list-decimal pl-6 space-y-2 my-4">
              <li>
                <strong>Starting state:</strong> Establish the character's initial condition, including flaws, limitations, or false beliefs.
              </li>
              <li>
                <strong>Desire and goal:</strong> Introduce what the character wants and the external goal that drives them.
              </li>
              <li>
                <strong>First challenge:</strong> Present an obstacle that reveals the character's approach to problems.
              </li>
              <li>
                <strong>Rising complications:</strong> Escalate challenges that force the character to adapt and reveal more of their nature.
              </li>
              <li>
                <strong>Moment of truth:</strong> Create a crisis that forces the character to confront their core flaw or belief.
              </li>
              <li>
                <strong>Transformation:</strong> Show the character's change through a meaningful choice or action.
              </li>
              <li>
                <strong>New state:</strong> Demonstrate the character's new condition after their journey.
              </li>
            </ol>
            
            <Quote 
              text="Character is plot, plot is character."
              author="F. Scott Fitzgerald"
            />
            
            <h3 className="text-xl font-semibold mt-6 mb-3">Integrating Character Arcs with Plot</h3>
            
            <p>
              Character arcs and plot development should be interwoven:
            </p>
            
            <ul className="list-disc pl-6 space-y-2 my-4">
              <li>
                <strong>External events challenge internal beliefs:</strong> Plot events should test the character's worldview and values.
              </li>
              <li>
                <strong>Character decisions drive plot:</strong> Major plot developments should result from character choices rather than coincidence.
              </li>
              <li>
                <strong>Internal change affects external action:</strong> As characters evolve, their approach to challenges should reflect their growth.
              </li>
              <li>
                <strong>Thematic resonance:</strong> Character arcs often embody or explore the novel's central themes.
              </li>
            </ul>
            
            <TipBox title="Character Arc Mapping">
              <p>
                Create a visual map of your character's arc by:
              </p>
              <ol className="list-decimal pl-5 space-y-1 mt-2">
                <li>Identifying their starting belief or flaw</li>
                <li>Listing key scenes that challenge this belief</li>
                <li>Noting how the character responds to each challenge</li>
                <li>Marking the turning point where change begins</li>
                <li>Describing their final state and how it differs from the beginning</li>
              </ol>
              <p className="mt-2">
                This map can help you ensure your character's development is consistent and meaningful throughout your novel.
              </p>
            </TipBox>
          </Section>
          
          <Section title="Character Relationships">
            <p>
              Characters don't exist in isolation. Their relationships with other characters reveal different facets of their personalities, create conflict, and drive plot development. Well-crafted relationships add depth and authenticity to your novel.
            </p>
            
            <h3 className="text-xl font-semibold mt-6 mb-3">Types of Character Relationships</h3>
            
            <p>
              Consider developing various relationship dynamics in your novel:
            </p>
            
            <ul className="list-disc pl-6 space-y-2 my-4">
              <li>
                <strong>Allies and friendships:</strong> Characters who support and help each other, though not without occasional conflict.
              </li>
              <li>
                <strong>Romantic relationships:</strong> Connections that explore attraction, intimacy, and commitment with all their complexities.
              </li>
              <li>
                <strong>Family relationships:</strong> Bonds of blood or choice that carry history, expectations, and deep emotional ties.
              </li>
              <li>
                <strong>Mentorships:</strong> Relationships where one character guides another's development or learning.
              </li>
              <li>
                <strong>Rivalries:</strong> Competitive relationships that may be friendly or hostile.
              </li>
              <li>
                <strong>Adversarial relationships:</strong> Connections between characters with opposing goals or values.
              </li>
              <li>
                <strong>Power dynamics:</strong> Relationships influenced by differences in authority, status, or control.
              </li>
            </ul>
            
            <h3 className="text-xl font-semibold mt-6 mb-3">Developing Dynamic Relationships</h3>
            
            <p>
              Like individual characters, relationships should evolve throughout your novel:
            </p>
            
            <ul className="list-disc pl-6 space-y-2 my-4">
              <li>
                <strong>Establish history:</strong> Consider how long characters have known each other and what experiences they've shared.
              </li>
              <li>
                <strong>Create shared and conflicting goals:</strong> Determine where characters' objectives align and where they diverge.
              </li>
              <li>
                <strong>Develop relationship arcs:</strong> Plan how relationships change over the course of your novel.
              </li>
              <li>
                <strong>Balance power:</strong> Consider how power shifts between characters in different contexts.
              </li>
              <li>
                <strong>Include subtext:</strong> Develop what remains unspoken between characters—tensions, attractions, resentments.
              </li>
            </ul>
            
            <Exercise title="Relationship Mapping">
              <p>Create a relationship map for your novel:</p>
              <ol className="list-decimal pl-6 space-y-1 mt-2">
                <li>Draw a circle for each major character</li>
                <li>Connect the circles with lines representing relationships</li>
                <li>Label each line with the nature of the relationship (friend, rival, family, etc.)</li>
                <li>Add a plus sign (+) for positive aspects and a minus sign (-) for tensions or conflicts</li>
                <li>Note how each relationship changes by the end of your novel</li>
              </ol>
              <p className="mt-3">
                This visual representation can help you identify underdeveloped relationships or potential for new interactions between characters.
              </p>
            </Exercise>
          </Section>
          
          <Section title="Character Voice and Dialogue">
            <p>
              A character's voice—how they speak, think, and express themselves—is crucial to bringing them to life on the page. Distinctive character voices help readers distinguish between characters and understand their personalities.
            </p>
            
            <h3 className="text-xl font-semibold mt-6 mb-3">Elements of Character Voice</h3>
            
            <p>
              Character voice encompasses:
            </p>
            
            <ul className="list-disc pl-6 space-y-2 my-4">
              <li>
                <strong>Vocabulary and word choice:</strong> The range and type of words a character uses.
              </li>
              <li>
                <strong>Sentence structure:</strong> Whether they speak in short, clipped sentences or long, flowing ones.
              </li>
              <li>
                <strong>Speech patterns:</strong> Distinctive phrases, verbal tics, or speech habits.
              </li>
              <li>
                <strong>Tone and attitude:</strong> The emotional quality that colors their communication.
              </li>
              <li>
                <strong>Cultural influences:</strong> How their background affects their expression.
              </li>
              <li>
                <strong>Education level:</strong> How their learning shapes their communication.
              </li>
              <li>
                <strong>Internal vs. external voice:</strong> How their thoughts differ from what they say aloud.
              </li>
            </ul>
            
            <h3 className="text-xl font-semibold mt-6 mb-3">Creating Distinctive Dialogue</h3>
            
            <p>
              Effective dialogue serves multiple functions:
            </p>
            
            <ul className="list-disc pl-6 space-y-2 my-4">
              <li>
                <strong>Reveals character:</strong> Shows personality, background, and emotional state.
              </li>
              <li>
                <strong>Advances plot:</strong> Moves the story forward through information exchange or conflict.
              </li>
              <li>
                <strong>Creates tension:</strong> Builds and releases tension between characters.
              </li>
              <li>
                <strong>Establishes relationships:</strong> Shows how characters interact and feel about each other.
              </li>
              <li>
                <strong>Provides exposition:</strong> Shares necessary information in a natural way.
              </li>
            </ul>
            
            <TipBox title="Dialogue Differentiation">
              <p>
                To create distinctive voices for multiple characters:
              </p>
              <ul className="list-disc pl-5 space-y-1 mt-2">
                <li>Give each character a unique verbal tic or favorite expression</li>
                <li>Vary sentence length and structure between characters</li>
                <li>Consider how education, background, and personality affect speech</li>
                <li>Create contrast between characters who speak formally and those who are casual</li>
                <li>Use dialogue tags sparingly, letting distinctive voices identify speakers</li>
                <li>Read dialogue aloud to test if each character sounds unique</li>
              </ul>
            </TipBox>
            
            <p>
              Remember that dialogue in fiction is not a transcript of real speech. It's a crafted representation that captures the essence of how people speak while serving narrative purposes. Good dialogue feels authentic without including all the hesitations, repetitions, and fillers of actual conversation.
            </p>
            
            <p className="mt-4">
              In the next section, we'll explore world-building—creating vivid, immersive settings that enhance your story and influence your characters.
            </p>
          </Section>
        </div>
        
        <div className="lg:col-span-1">
          <Sidebar links={sidebarLinks} />
        </div>
      </div>
    </Layout>
  );
}
