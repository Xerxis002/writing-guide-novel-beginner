import Layout from '@/components/ui/layout';
import { Section, Quote, TipBox, Exercise, Sidebar } from '@/components/ui/content-blocks';

export default function Page() {
  const sidebarLinks = [
    { title: 'Developing Self-Belief', href: '#developing-self-belief' },
    { title: 'Establishing a Writing Identity', href: '#establishing-a-writing-identity' },
    { title: 'Maintaining Long-Term Commitment', href: '#maintaining-long-term-commitment' },
    { title: 'Handling Criticism and Rejection', href: '#handling-criticism-and-rejection' },
    { title: 'Celebrating Progress', href: '#celebrating-progress' }
  ];

  return (
    <Layout>
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
        <div className="lg:col-span-3">
          <h1 className="text-4xl font-bold text-slate-900 mb-6">Building Confidence and Commitment</h1>
          
          <Section title="Developing Self-Belief">
            <p>
              Confidence in your writing ability doesn't come from talent alone—it's a skill you can develop through practice, mindset shifts, and strategic approaches to your creative work. Building self-belief is essential for sustaining your novel-writing journey through inevitable challenges.
            </p>
            
            <h3 className="text-xl font-semibold mt-6 mb-3">Understanding Confidence Challenges</h3>
            
            <p>
              Most writers struggle with confidence at some point. Common challenges include:
            </p>
            
            <ul className="list-disc pl-6 space-y-2 my-4">
              <li>
                <strong>Impostor syndrome:</strong> Feeling like a fraud despite evidence of your capabilities.
              </li>
              <li>
                <strong>Comparison trap:</strong> Measuring your early drafts against published works.
              </li>
              <li>
                <strong>Perfectionism:</strong> Setting unrealistic standards that no draft could meet.
              </li>
              <li>
                <strong>Negative self-talk:</strong> Internal criticism that undermines your creative efforts.
              </li>
              <li>
                <strong>Catastrophic thinking:</strong> Assuming the worst about your writing and its reception.
              </li>
              <li>
                <strong>All-or-nothing thinking:</strong> Viewing yourself as either a brilliant writer or a complete failure.
              </li>
              <li>
                <strong>External validation dependence:</strong> Relying too heavily on others' approval.
              </li>
            </ul>
            
            <p>
              Recognizing these patterns is the first step toward developing healthier approaches to your writing practice.
            </p>
            
            <Quote 
              text="The worst enemy to creativity is self-doubt."
              author="Sylvia Plath"
            />
            
            <h3 className="text-xl font-semibold mt-6 mb-3">Mindset Shifts for Building Confidence</h3>
            
            <p>
              These perspective changes can transform your relationship with writing:
            </p>
            
            <ul className="list-disc pl-6 space-y-2 my-4">
              <li>
                <strong>Embrace the learning journey:</strong> See yourself as a developing writer who improves with practice rather than someone who either "has talent" or doesn't.
              </li>
              <li>
                <strong>Separate self-worth from writing:</strong> Your value as a person is not determined by the quality of your current draft.
              </li>
              <li>
                <strong>Focus on process over product:</strong> Find satisfaction in the act of writing rather than solely in the outcome.
              </li>
              <li>
                <strong>Adopt a growth mindset:</strong> View challenges as opportunities to develop rather than evidence of limitations.
              </li>
              <li>
                <strong>Embrace imperfection:</strong> Recognize that all first drafts are imperfect and that revision is where the magic happens.
              </li>
              <li>
                <strong>Value persistence over inspiration:</strong> Understand that consistent effort matters more than sporadic brilliance.
              </li>
              <li>
                <strong>See feedback as information:</strong> Treat critique as useful data rather than personal judgment.
              </li>
            </ul>
            
            <TipBox title="Confidence-Building Practices">
              <p>
                Try these practical approaches to strengthen your writing confidence:
              </p>
              <ul className="list-disc pl-5 space-y-1 mt-2">
                <li>Keep a "wins" journal documenting all writing achievements, no matter how small</li>
                <li>Create a folder of positive feedback and encouraging comments to review when doubt strikes</li>
                <li>Develop a list of affirmations specific to your writing journey</li>
                <li>Practice mindfulness to recognize and interrupt negative thought patterns</li>
                <li>Set process-based goals (e.g., writing time) rather than outcome-based goals (e.g., publishing)</li>
                <li>Deliberately write something "just for fun" with no pressure for quality</li>
                <li>Read interviews with favorite authors about their struggles and doubts</li>
              </ul>
            </TipBox>
            
            <h3 className="text-xl font-semibold mt-6 mb-3">Developing Technical Confidence</h3>
            
            <p>
              Confidence also comes from knowing you have the skills to execute your vision:
            </p>
            
            <ul className="list-disc pl-6 space-y-2 my-4">
              <li>
                <strong>Identify skill gaps:</strong> Honestly assess which aspects of writing you need to develop.
              </li>
              <li>
                <strong>Create a learning plan:</strong> Systematically address those areas through books, courses, or practice.
              </li>
              <li>
                <strong>Study craft deliberately:</strong> Analyze how favorite authors handle elements you find challenging.
              </li>
              <li>
                <strong>Practice specific techniques:</strong> Focus exercises on particular skills rather than always working on your novel.
              </li>
              <li>
                <strong>Seek targeted feedback:</strong> Ask for input on specific aspects of your writing you're working to improve.
              </li>
              <li>
                <strong>Track your progress:</strong> Periodically review older work to see how far you've come.
              </li>
              <li>
                <strong>Develop problem-solving strategies:</strong> Build a toolkit of approaches for common writing challenges.
              </li>
            </ul>
            
            <Exercise title="Confidence Inventory">
              <p>Complete this exercise to build awareness of your confidence patterns:</p>
              <ol className="list-decimal pl-6 space-y-1 mt-2">
                <li>List three aspects of writing where you feel most confident (e.g., dialogue, description, character development)</li>
                <li>Identify three aspects where you feel least confident</li>
                <li>For each area of low confidence, write down:
                  <ul className="list-disc pl-5 mt-1 mb-2">
                    <li>A specific example of when you've done this well, even briefly</li>
                    <li>One resource or practice that could help you improve</li>
                    <li>A small, achievable goal to build skill in this area</li>
                  </ul>
                </li>
                <li>Write down three negative thoughts you frequently have about your writing</li>
                <li>Create a more balanced, realistic alternative to each negative thought</li>
                <li>Identify three specific actions you can take when self-doubt becomes overwhelming</li>
              </ol>
              <p className="mt-3">
                Review and update this inventory regularly as your confidence and skills evolve.
              </p>
            </Exercise>
          </Section>
          
          <Section title="Establishing a Writing Identity">
            <p>
              Developing a strong sense of yourself as a writer—regardless of publication status or external validation—provides an anchor for your creative journey and helps sustain your commitment through challenges.
            </p>
            
            <h3 className="text-xl font-semibold mt-6 mb-3">Claiming Your Writer Identity</h3>
            
            <p>
              Many beginning writers struggle to call themselves "writers," feeling they haven't earned the title. Consider these perspectives:
            </p>
            
            <ul className="list-disc pl-6 space-y-2 my-4">
              <li>
                <strong>Writers write:</strong> The act of writing itself makes you a writer, not publication or payment.
              </li>
              <li>
                <strong>Identity shapes behavior:</strong> Seeing yourself as a writer motivates consistent writing practice.
              </li>
              <li>
                <strong>Internal validation matters:</strong> Your self-definition doesn't require external confirmation.
              </li>
              <li>
                <strong>Identity evolves:</strong> Your sense of yourself as a writer will develop and deepen over time.
              </li>
              <li>
                <strong>Multiple identities coexist:</strong> Being a writer can complement other aspects of who you are.
              </li>
            </ul>
            
            <p>
              Practical steps to strengthen your writer identity:
            </p>
            
            <ul className="list-disc pl-6 space-y-2 my-4">
              <li>
                <strong>Use the language:</strong> Practice saying "I am a writer" or "I'm working on a novel."
              </li>
              <li>
                <strong>Create writing space:</strong> Designate a physical area, however small, for your writing practice.
              </li>
              <li>
                <strong>Establish rituals:</strong> Develop routines that signal your transition into writing mode.
              </li>
              <li>
                <strong>Connect with other writers:</strong> Join communities where your identity as a writer is recognized.
              </li>
              <li>
                <strong>Invest in your craft:</strong> Purchase books, take courses, or attend events related to writing.
              </li>
              <li>
                <strong>Share your work:</strong> Begin sharing writing with trusted readers when you're ready.
              </li>
              <li>
                <strong>Document your journey:</strong> Keep a record of your development as a writer.
              </li>
            </ul>
            
            <h3 className="text-xl font-semibold mt-6 mb-3">Finding Your Authentic Voice</h3>
            
            <p>
              Developing your unique voice strengthens your writing identity and increases confidence:
            </p>
            
            <ul className="list-disc pl-6 space-y-2 my-4">
              <li>
                <strong>Write what matters to you:</strong> Focus on subjects, themes, and stories you genuinely care about.
              </li>
              <li>
                <strong>Identify your values:</strong> Clarify what principles and beliefs inform your writing.
              </li>
              <li>
                <strong>Recognize your patterns:</strong> Notice recurring themes, approaches, or perspectives in your work.
              </li>
              <li>
                <strong>Embrace your quirks:</strong> The unusual aspects of your writing often become your strengths.
              </li>
              <li>
                <strong>Study influences thoughtfully:</strong> Learn from writers you admire without trying to become them.
              </li>
              <li>
                <strong>Write from experience:</strong> Draw on your unique life perspective, even in fictional contexts.
              </li>
              <li>
                <strong>Trust your instincts:</strong> Pay attention to what feels right or true in your writing.
              </li>
            </ul>
            
            <Quote 
              text="Don't try to figure out what other people want to hear from you; figure out what you have to say."
              author="Barbara Kingsolver"
            />
            
            <h3 className="text-xl font-semibold mt-6 mb-3">Creating a Personal Writing Philosophy</h3>
            
            <p>
              Developing your own philosophy of writing provides guidance and reinforces your identity:
            </p>
            
            <ul className="list-disc pl-6 space-y-2 my-4">
              <li>
                <strong>Define your purpose:</strong> Clarify why writing matters to you personally.
              </li>
              <li>
                <strong>Articulate your goals:</strong> Identify what you hope to achieve through your writing.
              </li>
              <li>
                <strong>Establish your principles:</strong> Determine the values that guide your writing practice.
              </li>
              <li>
                <strong>Consider your ideal reader:</strong> Envision who you're writing for and what you hope to offer them.
              </li>
              <li>
                <strong>Reflect on your process:</strong> Acknowledge how you work best and what conditions support your creativity.
              </li>
              <li>
                <strong>Examine your relationship with writing:</strong> Consider what role writing plays in your life.
              </li>
              <li>
                <strong>Revisit and revise:</strong> Allow your philosophy to evolve as you grow as a writer.
              </li>
            </ul>
            
            <Exercise title="Writing Identity Statement">
              <p>Create a personal statement that captures your identity as a writer:</p>
              <ol className="list-decimal pl-6 space-y-1 mt-2">
                <li>Complete these sentences:
                  <ul className="list-disc pl-5 mt-1 mb-2">
                    <li>I write because...</li>
                    <li>My writing explores...</li>
                    <li>As a writer, I value...</li>
                    <li>My unique perspective includes...</li>
                    <li>I hope my writing offers readers...</li>
                    <li>My ideal writing process involves...</li>
                    <li>I know I'm a writer because...</li>
                  </ul>
                </li>
                <li>Review your responses and identify common themes or values</li>
                <li>Draft a 1-2 paragraph statement that synthesizes these elements into a cohesive expression of your writing identity</li>
                <li>Refine your statement until it resonates deeply with you</li>
                <li>Display this statement in your writing space or keep it somewhere you can review regularly</li>
              </ol>
              <p className="mt-3">
                This statement can serve as an anchor when doubt arises and a compass when making decisions about your writing journey.
              </p>
            </Exercise>
          </Section>
          
          <Section title="Maintaining Long-Term Commitment">
            <p>
              Novel writing is a marathon, not a sprint. Developing strategies for sustained commitment helps you complete your project and build a lasting writing practice.
            </p>
            
            <h3 className="text-xl font-semibold mt-6 mb-3">Understanding Motivation Cycles</h3>
            
            <p>
              Motivation naturally fluctuates throughout any long-term project:
            </p>
            
            <ul className="list-disc pl-6 space-y-2 my-4">
              <li>
                <strong>Initial enthusiasm:</strong> The exciting beginning phase when ideas feel fresh and possibilities endless.
              </li>
              <li>
                <strong>Reality check:</strong> The realization of the work involved and the challenges ahead.
              </li>
              <li>
                <strong>The messy middle:</strong> The longest phase, where progress feels slow and doubts emerge.
              </li>
              <li>
                <strong>Second wind:</strong> Renewed energy as the end comes into view and the project takes shape.
              </li>
              <li>
                <strong>Completion drive:</strong> The final push to finish, fueled by the desire to complete what you've started.
              </li>
            </ul>
            
            <p>
              Recognizing these natural cycles helps you prepare for motivation dips and develop strategies to work through them.
            </p>
            
            <h3 className="text-xl font-semibold mt-6 mb-3">Creating Sustainable Writing Habits</h3>
            
            <p>
              Habits reduce dependence on fluctuating motivation:
            </p>
            
            <ul className="list-disc pl-6 space-y-2 my-4">
              <li>
                <strong>Start small:</strong> Begin with manageable, consistent writing sessions that you can maintain.
              </li>
              <li>
                <strong>Link to existing habits:</strong> Connect writing to established routines in your day.
              </li>
              <li>
                <strong>Create environmental cues:</strong> Designate specific spaces, times, or rituals for writing.
              </li>
              <li>
                <strong>Remove friction:</strong> Eliminate obstacles that make starting your writing session difficult.
              </li>
              <li>
                <strong>Track consistency:</strong> Record your writing sessions to build momentum and accountability.
              </li>
              <li>
                <strong>Build in rewards:</strong> Create positive associations with your writing practice.
              </li>
              <li>
                <strong>Prepare for obstacles:</strong> Develop contingency plans for common interruptions.
              </li>
            </ul>
            
            <h3 className="text-xl font-semibold mt-6 mb-3">Setting Effective Goals</h3>
            
            <p>
              Well-designed goals support long-term commitment:
            </p>
            
            <ul className="list-disc pl-6 space-y-2 my-4">
              <li>
                <strong>Balance outcome and process goals:</strong> Focus on both what you want to achieve and the actions that will get you there.
              </li>
              <li>
                <strong>Create a goal hierarchy:</strong> Establish long-term, medium-term, and short-term objectives that connect to each other.
              </li>
              <li>
                <strong>Make goals specific and measurable:</strong> Define clear criteria for success.
              </li>
              <li>
                <strong>Set challenging but achievable targets:</strong> Push yourself without setting up for failure.
              </li>
              <li>
                <strong>Establish meaningful deadlines:</strong> Create timeframes that motivate rather than discourage.
              </li>
              <li>
                <strong>Review and adjust regularly:</strong> Modify goals based on progress and changing circumstances.
              </li>
              <li>
                <strong>Connect goals to values:</strong> Ensure your objectives align with what matters most to you.
              </li>
            </ul>
            
            <TipBox title="Commitment During Difficult Phases">
              <p>
                Strategies for maintaining momentum when motivation is low:
              </p>
              <ul className="list-disc pl-5 space-y-1 mt-2">
                <li>Temporarily reduce your daily word count goal to make showing up easier</li>
                <li>Focus on a small, manageable scene rather than thinking about the entire novel</li>
                <li>Use the "15-minute rule"—commit to writing for just 15 minutes, then decide whether to continue</li>
                <li>Switch to a different part of your novel that feels more engaging</li>
                <li>Change your environment to create a fresh perspective</li>
                <li>Connect with other writers for encouragement and accountability</li>
                <li>Revisit your initial inspiration or the core idea that excited you about this project</li>
                <li>Read work that reminds you why you love writing and what you aspire to create</li>
              </ul>
            </TipBox>
            
            <h3 className="text-xl font-semibold mt-6 mb-3">Building Support Systems</h3>
            
            <p>
              External support strengthens internal commitment:
            </p>
            
            <ul className="list-disc pl-6 space-y-2 my-4">
              <li>
                <strong>Writing communities:</strong> Join groups that provide encouragement, feedback, and shared experience.
              </li>
              <li>
                <strong>Accountability partners:</strong> Establish regular check-ins with fellow writers.
              </li>
              <li>
                <strong>Mentors:</strong> Seek guidance from more experienced writers.
              </li>
              <li>
                <strong>Supportive friends and family:</strong> Communicate your writing goals to loved ones who can encourage you.
              </li>
              <li>
                <strong>Professional support:</strong> Consider writing coaches, classes, or workshops during challenging phases.
              </li>
              <li>
                <strong>Online resources:</strong> Utilize forums, social media groups, or digital tools for writers.
              </li>
              <li>
                <strong>Writing events:</strong> Participate in conferences, retreats, or local gatherings to renew inspiration.
              </li>
            </ul>
            
            <Exercise title="Commitment Strategy Plan">
              <p>Develop a personalized plan for maintaining long-term commitment:</p>
              <ol className="list-decimal pl-6 space-y-1 mt-2">
                <li>Identify your three biggest commitment challenges (e.g., time constraints, self-doubt, distractions)</li>
                <li>For each challenge, develop two specific strategies to address it</li>
                <li>Create a "minimum viable writing session" definition for days when motivation is low</li>
                <li>List three people who can provide support and how you'll engage with them</li>
                <li>Establish a regular schedule for reviewing and adjusting your goals</li>
                <li>Define what "success" means for you beyond completing your novel</li>
                <li>Write a letter to your future self to read when commitment wavers, reminding yourself why this project matters</li>
              </ol>
              <p className="mt-3">
                Keep this plan accessible and review it whenever you feel your commitment flagging.
              </p>
            </Exercise>
          </Section>
          
          <Section title="Handling Criticism and Rejection">
            <p>
              Learning to process feedback constructively and manage rejection is essential for any writer's long-term success and emotional wellbeing.
            </p>
            
            <h3 className="text-xl font-semibold mt-6 mb-3">The Emotional Impact of Criticism</h3>
            
            <p>
              Understanding your reactions to criticism helps you respond more effectively:
            </p>
            
            <ul className="list-disc pl-6 space-y-2 my-4">
              <li>
                <strong>Creative vulnerability:</strong> Creative work inherently exposes parts of ourselves, making criticism feel personal.
              </li>
              <li>
                <strong>Confirmation bias:</strong> We tend to focus on negative feedback that confirms our insecurities.
              </li>
              <li>
                <strong>Emotional flooding:</strong> Criticism can trigger strong emotions that temporarily overwhelm rational thought.
              </li>
              <li>
                <strong>Identity threat:</strong> Feedback can challenge our self-concept as writers or creative people.
              </li>
              <li>
                <strong>Perfectionism activation:</strong> Criticism may trigger perfectionistic tendencies and all-or-nothing thinking.
              </li>
              <li>
                <strong>Shame response:</strong> Some writers experience shame rather than simply disappointment when receiving criticism.
              </li>
            </ul>
            
            <p>
              These reactions are normal and don't reflect weakness—they're part of the human creative experience.
            </p>
            
            <h3 className="text-xl font-semibold mt-6 mb-3">Developing Criticism Resilience</h3>
            
            <p>
              These strategies help you benefit from feedback while protecting your creative confidence:
            </p>
            
            <ul className="list-disc pl-6 space-y-2 my-4">
              <li>
                <strong>Create emotional distance:</strong> Allow time between receiving feedback and responding to it.
              </li>
              <li>
                <strong>Separate identity from work:</strong> Remember that criticism of your writing isn't criticism of you.
              </li>
              <li>
                <strong>Focus on specifics:</strong> Extract actionable suggestions rather than dwelling on general negative impressions.
              </li>
              <li>
                <strong>Look for patterns:</strong> Pay special attention when multiple readers identify the same issue.
              </li>
              <li>
                <strong>Consider the source:</strong> Weigh feedback based on the reader's expertise and understanding of your goals.
              </li>
              <li>
                <strong>Maintain decision authority:</strong> Remember that you decide which feedback to implement.
              </li>
              <li>
                <strong>Practice self-compassion:</strong> Treat yourself with the kindness you would offer a friend receiving criticism.
              </li>
            </ul>
            
            <Quote 
              text="When people tell you something's wrong or doesn't work for them, they are almost always right. When they tell you exactly what they think is wrong and how to fix it, they are almost always wrong."
              author="Neil Gaiman"
            />
            
            <h3 className="text-xl font-semibold mt-6 mb-3">Managing Rejection</h3>
            
            <p>
              Rejection is an inevitable part of a writer's journey. These approaches help you handle it constructively:
            </p>
            
            <ul className="list-disc pl-6 space-y-2 my-4">
              <li>
                <strong>Normalize rejection:</strong> Recognize that all writers, even the most successful, face rejection.
              </li>
              <li>
                <strong>Understand the odds:</strong> Publishing is highly competitive, and rejection often reflects market factors rather than quality.
              </li>
              <li>
                <strong>Separate rejection from failure:</strong> A rejected manuscript is not a failed one—it's part of the process.
              </li>
              <li>
                <strong>Look for value:</strong> Extract any useful feedback from personalized rejections.
              </li>
              <li>
                <strong>Maintain perspective:</strong> One rejection represents a single opinion, not a universal judgment.
              </li>
              <li>
                <strong>Focus on what you control:</strong> Channel energy into improving your work rather than dwelling on rejection.
              </li>
              <li>
                <strong>Celebrate submissions:</strong> View each submission as a success regardless of outcome—you're actively participating in the process.
              </li>
            </ul>
            
            <TipBox title="Criticism Response Protocol">
              <p>
                When receiving difficult feedback, follow these steps:
              </p>
              <ol className="list-decimal pl-5 space-y-1 mt-2">
                <li>Thank the person for their time and input (even if you disagree)</li>
                <li>Resist the urge to explain, defend, or immediately respond to specific points</li>
                <li>Take at least 24 hours before reviewing the feedback in detail</li>
                <li>When reviewing, first identify any positive comments or what resonated with the reader</li>
                <li>Categorize critical feedback as:
                  <ul className="list-disc pl-5 mt-1 mb-1">
                    <li>Technical issues (grammar, structure, etc.)</li>
                    <li>Content concerns (plot, character, pacing, etc.)</li>
                    <li>Subjective reactions (personal preferences, taste)</li>
                  </ul>
                </li>
                <li>Consider which points align with your vision for the work</li>
                <li>Develop an action plan for addressing the most valuable feedback</li>
                <li>Express gratitude again when implementing suggestions</li>
              </ol>
              <p className="mt-2">
                This structured approach helps you process feedback objectively and extract maximum value from it.
              </p>
            </TipBox>
          </Section>
          
          <Section title="Celebrating Progress">
            <p>
              Acknowledging and celebrating your writing achievements—both large and small—sustains motivation, builds confidence, and creates a positive relationship with your creative practice.
            </p>
            
            <h3 className="text-xl font-semibold mt-6 mb-3">Recognizing Different Types of Progress</h3>
            
            <p>
              Progress in writing takes many forms beyond word count or completed manuscripts:
            </p>
            
            <ul className="list-disc pl-6 space-y-2 my-4">
              <li>
                <strong>Skill development:</strong> Improvements in specific aspects of your craft.
              </li>
              <li>
                <strong>Process refinement:</strong> Greater understanding of how you work best.
              </li>
              <li>
                <strong>Habit formation:</strong> Establishing consistent writing practices.
              </li>
              <li>
                <strong>Mindset shifts:</strong> Developing healthier attitudes toward writing and criticism.
              </li>
              <li>
                <strong>Creative breakthroughs:</strong> Solving persistent story problems or finding new approaches.
              </li>
              <li>
                <strong>Courage milestones:</strong> Taking risks like sharing work or submitting for publication.
              </li>
              <li>
                <strong>Community building:</strong> Developing relationships with other writers and readers.
              </li>
            </ul>
            
            <p>
              Expanding your definition of progress helps you recognize growth even when tangible outcomes seem distant.
            </p>
            
            <h3 className="text-xl font-semibold mt-6 mb-3">Creating Meaningful Milestones</h3>
            
            <p>
              Breaking your novel-writing journey into meaningful milestones provides regular opportunities for celebration:
            </p>
            
            <ul className="list-disc pl-6 space-y-2 my-4">
              <li>
                <strong>Project preparation:</strong> Completing research, outlining, character development.
              </li>
              <li>
                <strong>Word count targets:</strong> Reaching specific cumulative word counts (10K, 25K, 50K, etc.).
              </li>
              <li>
                <strong>Structural points:</strong> Completing the first chapter, reaching the midpoint, finishing Act 2, etc.
              </li>
              <li>
                <strong>Draft completion:</strong> Finishing the first draft, second draft, final draft.
              </li>
              <li>
                <strong>Feedback stages:</strong> Sharing with first readers, incorporating revision suggestions.
              </li>
              <li>
                <strong>Submission goals:</strong> Preparing query letters, submitting to agents or publishers.
              </li>
              <li>
                <strong>Time investments:</strong> Completing 30 days of consistent writing, 100 hours on your project, etc.
              </li>
            </ul>
            
            <p>
              For each milestone, consider:
            </p>
            
            <ul className="list-disc pl-6 space-y-2 my-4">
              <li>
                <strong>How you'll track it:</strong> The specific measure or indicator of completion.
              </li>
              <li>
                <strong>How you'll document it:</strong> Where you'll record this achievement.
              </li>
              <li>
                <strong>How you'll celebrate it:</strong> The meaningful reward or acknowledgment.
              </li>
              <li>
                <strong>Who you'll share it with:</strong> The people who will appreciate this milestone.
              </li>
            </ul>
            
            <h3 className="text-xl font-semibold mt-6 mb-3">Designing Meaningful Celebrations</h3>
            
            <p>
              Effective celebrations reinforce your writing identity and create positive associations with your practice:
            </p>
            
            <ul className="list-disc pl-6 space-y-2 my-4">
              <li>
                <strong>Align with values:</strong> Choose celebrations that connect to what matters to you.
              </li>
              <li>
                <strong>Scale appropriately:</strong> Match the significance of the celebration to the milestone.
              </li>
              <li>
                <strong>Create writing-related rewards:</strong> Consider celebrations that support your writing journey (new books, writing tools, courses).
              </li>
              <li>
                <strong>Include social elements:</strong> Share achievements with people who understand their significance.
              </li>
              <li>
                <strong>Document the moment:</strong> Create a record of your achievement and celebration.
              </li>
              <li>
                <strong>Build traditions:</strong> Develop personal rituals for different types of writing accomplishments.
              </li>
              <li>
                <strong>Include reflection:</strong> Take time to appreciate the growth represented by each milestone.
              </li>
            </ul>
            
            <Exercise title="Progress Celebration System">
              <p>Design a personalized system for tracking and celebrating your writing progress:</p>
              <ol className="list-decimal pl-6 space-y-1 mt-2">
                <li>Create a list of 10-15 specific, measurable milestones for your current writing project</li>
                <li>For each milestone, define:
                  <ul className="list-disc pl-5 mt-1 mb-2">
                    <li>How you'll know when you've reached it</li>
                    <li>A small celebration for achieving it</li>
                    <li>Where you'll record this achievement</li>
                  </ul>
                </li>
                <li>Design a visual tracking system (chart, calendar, journal) to monitor your progress</li>
                <li>Identify 3-5 significant milestones that deserve larger celebrations</li>
                <li>Plan these celebrations in detail, including who you might share them with</li>
                <li>Create a "writing wins" journal or digital file where you record all achievements, including unexpected ones</li>
                <li>Schedule a monthly review of your progress and celebrations</li>
              </ol>
              <p className="mt-3">
                Implement this system immediately and adjust it as you discover what types of tracking and celebration most motivate you.
              </p>
            </Exercise>
            
            <h3 className="text-xl font-semibold mt-6 mb-3">The Journey Continues</h3>
            
            <p>
              As you conclude this guide, remember that becoming a novelist is not a destination but a continuous journey of growth, discovery, and creation. Each novel you write will teach you something new about your craft and yourself.
            </p>
            
            <p className="mt-4">
              The path of a writer includes challenges and triumphs, doubts and breakthroughs, solitary work and community connection. By developing your skills, nurturing your confidence, and maintaining your commitment, you create not just stories but a meaningful creative practice that can enrich your life for years to come.
            </p>
            
            <p className="mt-4">
              Your unique voice and perspective are valuable. The world needs the stories that only you can tell. Trust in your ability to grow as a writer, be patient with your process, and take pride in the courage it takes to bring your imagination to life on the page.
            </p>
            
            <p className="mt-4">
              Now, return to your novel with renewed purpose and confidence. Your readers are waiting.
            </p>
            
            <Quote 
              text="The greatest part of a writer's time is spent in reading, in order to write; a man will turn over half a library to make one book."
              author="Samuel Johnson"
            />
          </Section>
        </div>
        
        <div className="lg:col-span-1">
          <Sidebar links={sidebarLinks} />
        </div>
      </div>
    </Layout>
  );
}
