import Layout from '@/components/ui/layout';
import { Section, Quote, TipBox, Exercise, Sidebar } from '@/components/ui/content-blocks';

export default function Page() {
  const sidebarLinks = [
    { title: 'Dialogue Fundamentals', href: '#dialogue-fundamentals' },
    { title: 'Creating Authentic Dialogue', href: '#creating-authentic-dialogue' },
    { title: 'Dialogue Mechanics', href: '#dialogue-mechanics' },
    { title: 'Finding Your Voice', href: '#finding-your-voice' },
    { title: 'Point of View and Narrative Voice', href: '#point-of-view-and-narrative-voice' }
  ];

  return (
    <Layout>
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
        <div className="lg:col-span-3">
          <h1 className="text-4xl font-bold text-slate-900 mb-6">Dialogue and Voice</h1>
          
          <Section title="Dialogue Fundamentals">
            <p>
              Dialogue is one of the most powerful tools in a novelist's toolkit. Well-crafted dialogue brings characters to life, advances your plot, reveals information, and creates a sense of immediacy that draws readers into your story.
            </p>
            
            <p>
              At its core, dialogue is a representation of human speech—not a transcript of it. Effective fictional dialogue captures the essence of how people speak while serving narrative purposes.
            </p>
            
            <h3 className="text-xl font-semibold mt-6 mb-3">The Functions of Dialogue</h3>
            
            <p>
              Dialogue serves multiple purposes in your novel:
            </p>
            
            <ul className="list-disc pl-6 space-y-2 my-4">
              <li>
                <strong>Reveals character:</strong> Speech patterns, word choice, and topics of conversation reveal personality, background, and emotional state.
              </li>
              <li>
                <strong>Advances plot:</strong> Conversations can introduce new information, create conflicts, or resolve problems.
              </li>
              <li>
                <strong>Provides exposition:</strong> Dialogue can convey necessary background information in a natural way.
              </li>
              <li>
                <strong>Creates tension:</strong> Verbal exchanges can build and release tension between characters.
              </li>
              <li>
                <strong>Establishes relationships:</strong> How characters speak to each other reveals their dynamics and feelings.
              </li>
              <li>
                <strong>Adds pace and rhythm:</strong> Dialogue typically moves faster than description, helping control your novel's pacing.
              </li>
            </ul>
            
            <Quote 
              text="Dialogue is not just quotation. It is grimaces, pauses, adjustments of blouse buttons, doodles on a napkin, and crossings of legs."
              author="Jerome Stern"
            />
            
            <h3 className="text-xl font-semibold mt-6 mb-3">Dialogue vs. Real Speech</h3>
            
            <p>
              Effective dialogue is not a verbatim reproduction of how people actually speak. It's a crafted representation that:
            </p>
            
            <ul className="list-disc pl-6 space-y-2 my-4">
              <li>
                <strong>Eliminates mundane exchanges:</strong> "Hello," "How are you?" and other pleasantries are often skipped unless they serve a purpose.
              </li>
              <li>
                <strong>Reduces repetition:</strong> Real speech contains many repeated words and phrases that would be tedious to read.
              </li>
              <li>
                <strong>Minimizes fillers:</strong> "Um," "uh," "like," and similar fillers are used sparingly, only when they reveal character.
              </li>
              <li>
                <strong>Focuses on purpose:</strong> Each line of dialogue should advance character, plot, or theme in some way.
              </li>
              <li>
                <strong>Maintains clarity:</strong> Even when depicting confused or inarticulate characters, the meaning must be clear to readers.
              </li>
            </ul>
            
            <p>
              The goal is to create dialogue that feels authentic while being more purposeful, concise, and engaging than actual conversation.
            </p>
          </Section>
          
          <Section title="Creating Authentic Dialogue">
            <p>
              Authentic dialogue sounds natural while revealing character and advancing your story. Creating distinctive voices for different characters helps readers distinguish between them and understand their personalities.
            </p>
            
            <h3 className="text-xl font-semibold mt-6 mb-3">Elements of Character Voice</h3>
            
            <p>
              Consider these aspects when developing a character's dialogue voice:
            </p>
            
            <ul className="list-disc pl-6 space-y-2 my-4">
              <li>
                <strong>Vocabulary and word choice:</strong> The range and type of words a character uses.
              </li>
              <li>
                <strong>Sentence structure:</strong> Whether they speak in short, clipped sentences or long, flowing ones.
              </li>
              <li>
                <strong>Speech patterns:</strong> Distinctive phrases, verbal tics, or speech habits.
              </li>
              <li>
                <strong>Tone and attitude:</strong> The emotional quality that colors their communication.
              </li>
              <li>
                <strong>Cultural influences:</strong> How their background affects their expression.
              </li>
              <li>
                <strong>Education level:</strong> How their learning shapes their communication.
              </li>
              <li>
                <strong>Generational markers:</strong> Age-specific references or speech patterns.
              </li>
              <li>
                <strong>Professional jargon:</strong> Specialized language from their occupation.
              </li>
            </ul>
            
            <TipBox title="Dialogue Differentiation">
              <p>
                To create distinctive voices for multiple characters:
              </p>
              <ul className="list-disc pl-5 space-y-1 mt-2">
                <li>Give each character a unique verbal tic or favorite expression</li>
                <li>Vary sentence length and structure between characters</li>
                <li>Consider how education, background, and personality affect speech</li>
                <li>Create contrast between characters who speak formally and those who are casual</li>
                <li>Use dialogue tags sparingly, letting distinctive voices identify speakers</li>
                <li>Read dialogue aloud to test if each character sounds unique</li>
              </ul>
            </TipBox>
            
            <h3 className="text-xl font-semibold mt-6 mb-3">Subtext in Dialogue</h3>
            
            <p>
              Subtext is what lies beneath the surface of dialogue—the unspoken meanings, emotions, and intentions that characters may be hiding or unable to express directly.
            </p>
            
            <p>
              Effective subtext:
            </p>
            
            <ul className="list-disc pl-6 space-y-2 my-4">
              <li>
                <strong>Creates depth:</strong> Adds layers of meaning to conversations.
              </li>
              <li>
                <strong>Builds tension:</strong> What's not said can be more powerful than what is.
              </li>
              <li>
                <strong>Engages readers:</strong> Invites readers to interpret and understand what's happening beneath the words.
              </li>
              <li>
                <strong>Reflects real human interaction:</strong> People rarely say exactly what they mean or feel.
              </li>
            </ul>
            
            <p>
              To create effective subtext, consider:
            </p>
            
            <ul className="list-disc pl-6 space-y-2 my-4">
              <li>
                <strong>What the character wants to say vs. what they actually say</strong>
              </li>
              <li>
                <strong>What the character is trying to hide</strong>
              </li>
              <li>
                <strong>The history between characters that influences their communication</strong>
              </li>
              <li>
                <strong>The power dynamics that affect what can be said openly</strong>
              </li>
              <li>
                <strong>Cultural or social constraints on expression</strong>
              </li>
            </ul>
            
            <Exercise title="Dialogue with Subtext">
              <p>Write a brief dialogue scene between two characters where:</p>
              <ol className="list-decimal pl-6 space-y-1 mt-2">
                <li>One character wants something from the other but doesn't ask directly</li>
                <li>The second character understands the request but has reasons to refuse</li>
                <li>Neither character explicitly states their true thoughts or feelings</li>
                <li>The conversation appears to be about something else entirely</li>
                <li>The reader can understand what's really happening through context and subtext</li>
              </ol>
              <p className="mt-3">
                This exercise helps you develop the art of writing dialogue where what's not said is as important as what is.
              </p>
            </Exercise>
          </Section>
          
          <Section title="Dialogue Mechanics">
            <p>
              The technical aspects of dialogue—how it's formatted, punctuated, and integrated with narrative—affect how readers experience your characters' conversations.
            </p>
            
            <h3 className="text-xl font-semibold mt-6 mb-3">Dialogue Tags and Attributions</h3>
            
            <p>
              Dialogue tags identify who is speaking. They can be simple attributions or more descriptive:
            </p>
            
            <ul className="list-disc pl-6 space-y-2 my-4">
              <li>
                <strong>Simple tags:</strong> "said," "asked," "replied"
              </li>
              <li>
                <strong>Descriptive tags:</strong> "whispered," "shouted," "muttered"
              </li>
              <li>
                <strong>Action tags:</strong> Actions that identify the speaker without using "said" or its variants
              </li>
            </ul>
            
            <p>
              Best practices for dialogue tags:
            </p>
            
            <ul className="list-disc pl-6 space-y-2 my-4">
              <li>
                <strong>Use "said" most often:</strong> It becomes invisible to readers and doesn't distract from the dialogue itself.
              </li>
              <li>
                <strong>Vary tag placement:</strong> Tags can come before, after, or in the middle of dialogue.
              </li>
              <li>
                <strong>Use descriptive tags sparingly:</strong> Reserve them for when the manner of speaking is important and not obvious from the dialogue.
              </li>
              <li>
                <strong>Consider omitting tags:</strong> When it's clear who's speaking, tags aren't always necessary.
              </li>
              <li>
                <strong>Use action tags for variety:</strong> "He poured another drink. 'I didn't expect to see you here.'"
              </li>
            </ul>
            
            <h3 className="text-xl font-semibold mt-6 mb-3">Punctuating Dialogue</h3>
            
            <p>
              Proper punctuation helps readers follow conversations:
            </p>
            
            <ul className="list-disc pl-6 space-y-2 my-4">
              <li>
                <strong>Use quotation marks:</strong> In most English-language fiction, dialogue is enclosed in double quotation marks.
              </li>
              <li>
                <strong>Punctuate inside quotation marks:</strong> Commas, periods, question marks, and exclamation points go inside the quotation marks.
              </li>
              <li>
                <strong>Start new paragraphs for new speakers:</strong> Each time the speaker changes, begin a new paragraph.
              </li>
              <li>
                <strong>Use commas with tags:</strong> When a dialogue tag follows the speech, use a comma inside the quotation marks: "I'm leaving," she said.
              </li>
              <li>
                <strong>Use periods with actions:</strong> When an action follows the speech (not a dialogue tag), use a period inside the quotation marks: "I'm leaving." She picked up her bag.
              </li>
              <li>
                <strong>For interrupted speech:</strong> Use em dashes for interruptions: "I was about to—"
              </li>
              <li>
                <strong>For trailing off:</strong> Use ellipses when speech fades: "I don't know if I can..."
              </li>
            </ul>
            
            <h3 className="text-xl font-semibold mt-6 mb-3">Balancing Dialogue and Narrative</h3>
            
            <p>
              Effective dialogue scenes blend speech with other narrative elements:
            </p>
            
            <ul className="list-disc pl-6 space-y-2 my-4">
              <li>
                <strong>Include action beats:</strong> Brief descriptions of what characters are doing as they speak.
              </li>
              <li>
                <strong>Add sensory details:</strong> What characters see, hear, smell, taste, or feel during the conversation.
              </li>
              <li>
                <strong>Show reactions:</strong> How characters respond physically or emotionally to what's being said.
              </li>
              <li>
                <strong>Include internal thoughts:</strong> What the viewpoint character is thinking but not saying.
              </li>
              <li>
                <strong>Describe environment:</strong> How the setting affects or reflects the conversation.
              </li>
            </ul>
            
            <TipBox title="Dialogue Revision Checklist">
              <p>
                When revising dialogue scenes, check that:
              </p>
              <ul className="list-disc pl-5 space-y-1 mt-2">
                <li>Each line serves a purpose (character development, plot advancement, etc.)</li>
                <li>Characters sound distinct from one another</li>
                <li>The conversation has a clear direction or purpose</li>
                <li>Dialogue is balanced with action, description, and internal thoughts</li>
                <li>Subtext adds depth to the exchange</li>
                <li>The scene maintains appropriate pacing</li>
                <li>Dialogue tags are used effectively and not overused</li>
                <li>Punctuation and formatting are correct and consistent</li>
              </ul>
            </TipBox>
          </Section>
          
          <Section title="Finding Your Voice">
            <p>
              Your authorial voice is the distinctive personality that comes through in your writing. It's what makes your work uniquely yours—a combination of your word choice, sentence structure, tone, rhythm, and perspective.
            </p>
            
            <h3 className="text-xl font-semibold mt-6 mb-3">Understanding Authorial Voice</h3>
            
            <p>
              Authorial voice encompasses:
            </p>
            
            <ul className="list-disc pl-6 space-y-2 my-4">
              <li>
                <strong>Diction:</strong> Your word choice and vocabulary range.
              </li>
              <li>
                <strong>Syntax:</strong> How you structure sentences and paragraphs.
              </li>
              <li>
                <strong>Tone:</strong> The emotional attitude conveyed in your writing.
              </li>
              <li>
                <strong>Rhythm:</strong> The cadence and flow of your prose.
              </li>
              <li>
                <strong>Perspective:</strong> The unique way you observe and interpret the world.
              </li>
              <li>
                <strong>Thematic concerns:</strong> The ideas and questions that recur in your work.
              </li>
              <li>
                <strong>Stylistic tendencies:</strong> Your characteristic approaches to description, dialogue, and narrative.
              </li>
            </ul>
            
            <p>
              A strong, authentic voice makes your writing memorable and creates a connection with readers who resonate with your particular way of telling stories.
            </p>
            
            <Quote 
              text="Don't try to figure out what other people want to hear from you; figure out what you have to say."
              author="Barbara Kingsolver"
            />
            
            <h3 className="text-xl font-semibold mt-6 mb-3">Developing Your Voice</h3>
            
            <p>
              Voice isn't something you create so much as something you discover and refine. These approaches can help:
            </p>
            
            <ul className="list-disc pl-6 space-y-2 my-4">
              <li>
                <strong>Read widely:</strong> Expose yourself to many different voices to understand the possibilities.
              </li>
              <li>
                <strong>Write regularly:</strong> Your natural voice emerges through consistent practice.
              </li>
              <li>
                <strong>Embrace your quirks:</strong> The idiosyncrasies in your writing often become the hallmarks of your voice.
              </li>
              <li>
                <strong>Write what matters to you:</strong> Your passion and authentic perspective come through when you care about your subject.
              </li>
              <li>
                <strong>Experiment:</strong> Try different styles and approaches to discover what feels most natural.
              </li>
              <li>
                <strong>Get feedback:</strong> Others can often identify distinctive elements of your voice that you might not notice.
              </li>
              <li>
                <strong>Refine, don't erase:</strong> Edit to strengthen your voice, not to conform to a perceived "correct" style.
              </li>
            </ul>
            
            <Exercise title="Voice Exploration">
              <p>Try these exercises to explore and develop your authorial voice:</p>
              <ol className="list-decimal pl-6 space-y-1 mt-2">
                <li>Write a description of the same scene in three different moods (joyful, melancholic, tense)</li>
                <li>Rewrite a paragraph from a favorite book in your own words and style</li>
                <li>Write about a meaningful personal experience, focusing on honesty rather than style</li>
                <li>Record yourself telling a story aloud, then transcribe and refine it to capture your natural storytelling voice</li>
                <li>Ask trusted readers what patterns, tendencies, or distinctive qualities they notice in your writing</li>
              </ol>
              <p className="mt-3">
                These exercises help you become more conscious of your natural tendencies and strengths as a writer.
              </p>
            </Exercise>
          </Section>
          
          <Section title="Point of View and Narrative Voice">
            <p>
              Point of view (POV) determines whose perspective the story is told from and how much access readers have to characters' thoughts and feelings. Your choice of POV profoundly affects the reader's experience and the narrative voice of your novel.
            </p>
            
            <h3 className="text-xl font-semibold mt-6 mb-3">Types of Point of View</h3>
            
            <p>
              The main POV options for fiction include:
            </p>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 my-6">
              <div className="bg-blue-50 p-4 rounded">
                <h4 className="font-semibold text-blue-800 mb-2">First Person</h4>
                <p className="mb-2">Told from the "I" perspective of a character within the story.</p>
                <p className="italic text-sm mb-2">"I watched as the door slowly opened, my heart pounding in my chest."</p>
                <ul className="list-disc pl-5 space-y-1 text-sm">
                  <li><strong>Strengths:</strong> Immediacy, intimacy, distinctive voice</li>
                  <li><strong>Limitations:</strong> Restricted to one character's knowledge and perceptions</li>
                </ul>
              </div>
              
              <div className="bg-green-50 p-4 rounded">
                <h4 className="font-semibold text-green-800 mb-2">Second Person</h4>
                <p className="mb-2">Addresses the reader as "you," making them a character in the story.</p>
                <p className="italic text-sm mb-2">"You watch as the door slowly opens, your heart pounding in your chest."</p>
                <ul className="list-disc pl-5 space-y-1 text-sm">
                  <li><strong>Strengths:</strong> Unique, immersive, creates immediacy</li>
                  <li><strong>Limitations:</strong> Can feel gimmicky, difficult to sustain for a novel</li>
                </ul>
              </div>
              
              <div className="bg-purple-50 p-4 rounded">
                <h4 className="font-semibold text-purple-800 mb-2">Third Person Limited</h4>
                <p className="mb-2">Focuses on "he/she/they" but limits perspective to one character at a time.</p>
                <p className="italic text-sm mb-2">"She watched as the door slowly opened, her heart pounding in her chest."</p>
                <ul className="list-disc pl-5 space-y-1 text-sm">
                  <li><strong>Strengths:</strong> Flexibility, intimacy with some objectivity</li>
                  <li><strong>Limitations:</strong> Still restricted to what the focal character knows</li>
                </ul>
              </div>
              
              <div className="bg-amber-50 p-4 rounded">
                <h4 className="font-semibold text-amber-800 mb-2">Third Person Omniscient</h4>
                <p className="mb-2">An all-knowing narrator who can access any character's thoughts and feelings.</p>
                <p className="italic text-sm mb-2">"As the door slowly opened, Maria's heart pounded in her chest, while John, on the other side, prepared himself for the confrontation."</p>
                <ul className="list-disc pl-5 space-y-1 text-sm">
                  <li><strong>Strengths:</strong> Complete freedom, ability to show multiple perspectives</li>
                  <li><strong>Limitations:</strong> Can create emotional distance, requires skillful handling</li>
                </ul>
              </div>
            </div>
            
            <h3 className="text-xl font-semibold mt-6 mb-3">Choosing the Right POV</h3>
            
            <p>
              Your choice of POV should serve your story's needs:
            </p>
            
            <ul className="list-disc pl-6 space-y-2 my-4">
              <li>
                <strong>Consider your genre:</strong> Some genres have traditional POV expectations (e.g., many thrillers use first person or close third).
              </li>
              <li>
                <strong>Think about your story's scope:</strong> Stories with multiple important storylines may benefit from multiple POVs.
              </li>
              <li>
                <strong>Consider information control:</strong> What do you want readers to know, and when do you want them to know it?
              </li>
              <li>
                <strong>Match POV to character:</strong> Some characters' voices and perspectives are more compelling than others.
              </li>
              <li>
                <strong>Consider your strengths:</strong> Choose a POV that plays to your abilities as a writer.
              </li>
            </ul>
            
            <h3 className="text-xl font-semibold mt-6 mb-3">Handling Multiple POVs</h3>
            
            <p>
              If your novel includes multiple viewpoint characters:
            </p>
            
            <ul className="list-disc pl-6 space-y-2 my-4">
              <li>
                <strong>Create clear transitions:</strong> Signal POV shifts with chapter or section breaks.
              </li>
              <li>
                <strong>Develop distinctive voices:</strong> Each viewpoint character should have a unique perspective and voice.
              </li>
              <li>
                <strong>Balance screen time:</strong> Consider how much attention each viewpoint character receives.
              </li>
              <li>
                <strong>Avoid head-hopping:</strong> Don't switch viewpoints within a scene without a clear break.
              </li>
              <li>
                <strong>Consider timing:</strong> Think about when to switch POVs for maximum impact (e.g., at cliffhanger moments).
              </li>
              <li>
                <strong>Ensure purpose:</strong> Each POV should add something essential to the story.
              </li>
            </ul>
            
            <TipBox title="POV Consistency">
              <p>
                Maintaining consistent POV is crucial for reader immersion:
              </p>
              <ul className="list-disc pl-5 space-y-1 mt-2">
                <li>Watch for accidental shifts in perspective within scenes</li>
                <li>Be careful not to include information a viewpoint character couldn't know</li>
                <li>Maintain consistent narrative distance (how close we are to the character's thoughts)</li>
                <li>Use consistent language that reflects the viewpoint character's vocabulary and perception</li>
                <li>When revising, read specifically for POV consistency</li>
              </ul>
            </TipBox>
            
            <p className="mt-4">
              In the next section, we'll explore editing and revision—the crucial process of refining your draft into a polished novel.
            </p>
          </Section>
        </div>
        
        <div className="lg:col-span-1">
          <Sidebar links={sidebarLinks} />
        </div>
      </div>
    </Layout>
  );
}
