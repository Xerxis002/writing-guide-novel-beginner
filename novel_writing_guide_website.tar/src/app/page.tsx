import Layout from '@/components/ui/layout';
import { Section, Quote, TipBox, Exercise, Sidebar } from '@/components/ui/content-blocks';

export default function Page() {
  const sidebarLinks = [
    { title: 'Introduction', href: '#introduction' },
    { title: 'Why Write a Novel?', href: '#why-write-a-novel' },
    { title: 'The Journey Ahead', href: '#the-journey-ahead' },
    { title: 'How to Use This Guide', href: '#how-to-use-this-guide' },
    { title: 'The Writer\'s Mindset', href: '#the-writers-mindset' }
  ];

  return (
    <Layout>
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
        <div className="lg:col-span-3">
          <h1 className="text-4xl font-bold text-slate-900 mb-6">The Complete Novel Writing Guide</h1>
          
          <Section title="Introduction">
            <p>
              Welcome to your comprehensive guide to novel writing. Whether you're taking your first steps into fiction writing or looking to refine your approach to the craft, this guide offers practical advice, creative techniques, and supportive strategies to help you bring your story to life.
            </p>
            
            <p>
              Writing a novel is both an art and a craft—a delicate balance between creative inspiration and technical skill. While there's no single "correct" way to write a novel, understanding fundamental principles and proven approaches can help you navigate the complex journey from initial idea to completed manuscript.
            </p>
            
            <Quote 
              text="There is no rule on how to write. Sometimes it comes easily and perfectly; sometimes it's like drilling rock and then blasting it out with charges."
              author="Ernest Hemingway"
            />
            
            <p>
              This guide embraces the diversity of writing approaches. Whether you're a meticulous planner who outlines every chapter before writing or an intuitive discoverer who finds the story through the writing process itself, you'll find techniques that support your natural creative style while helping you overcome common challenges.
            </p>
          </Section>
          
          <Section title="Why Write a Novel?">
            <p>
              Before diving into the how of novel writing, it's worth reflecting on the why. Writing a novel requires significant time, energy, and emotional investment. Understanding your personal motivations can provide crucial sustenance during challenging phases of the writing process.
            </p>
            
            <p>
              Common motivations for novel writing include:
            </p>
            
            <ul className="list-disc pl-6 space-y-2">
              <li><strong>Creative expression:</strong> The desire to create something meaningful and uniquely yours</li>
              <li><strong>Storytelling passion:</strong> A love of stories and the wish to craft your own</li>
              <li><strong>Processing experiences:</strong> Using fiction to explore and make sense of life experiences</li>
              <li><strong>Connecting with others:</strong> Creating emotional connections with readers through shared human experiences</li>
              <li><strong>Exploring ideas:</strong> Examining philosophical, social, or personal questions through narrative</li>
              <li><strong>Career aspirations:</strong> Building a career as a published author</li>
            </ul>
            
            <p>
              Your reasons may include several of these or something entirely different. What matters is that you identify what drives you personally—this awareness will help you maintain momentum and make decisions that align with your core purpose.
            </p>
            
            <Exercise title="Clarify Your Motivation">
              <p>Take a few minutes to write down your personal reasons for wanting to write a novel. Be honest with yourself—there are no wrong answers. Consider:</p>
              <ul className="list-disc pl-6 space-y-1">
                <li>What do you hope to gain from the experience?</li>
                <li>What would make this project feel successful to you?</li>
                <li>What stories are you uniquely positioned to tell?</li>
                <li>How does novel writing connect to your values or life purpose?</li>
              </ul>
              <p className="mt-2">Keep these reflections somewhere visible as you work through this guide and your novel.</p>
            </Exercise>
          </Section>
          
          <Section title="The Journey Ahead">
            <p>
              Novel writing is a journey with distinct phases, each with its own challenges and rewards. Understanding this landscape helps you navigate it more effectively and recognize your progress along the way.
            </p>
            
            <p>
              The novel-writing journey typically includes:
            </p>
            
            <ul className="list-disc pl-6 space-y-2">
              <li><strong>Ideation:</strong> Generating and developing your core concept</li>
              <li><strong>Planning:</strong> Creating characters, settings, and plot structures (varies by writing style)</li>
              <li><strong>Drafting:</strong> Writing the first complete version of your story</li>
              <li><strong>Revision:</strong> Refining and strengthening your manuscript</li>
              <li><strong>Polishing:</strong> Making final adjustments to language and presentation</li>
              <li><strong>Completion:</strong> Finishing your novel and deciding on next steps</li>
            </ul>
            
            <p>
              This guide addresses each of these phases, providing specific techniques to help you move through them successfully. Remember that writing is rarely a linear process—you'll likely cycle through some phases multiple times, especially planning and revision.
            </p>
            
            <TipBox title="Embrace Your Unique Process">
              <p>
                While this guide presents a structured approach to novel writing, your actual process may be more fluid. Some writers plan extensively before writing a word; others discover their story as they write. Some revise as they go; others complete an entire draft before making changes.
              </p>
              <p>
                Pay attention to what works for you, and adapt the techniques in this guide to support your natural creative rhythm rather than fighting against it.
              </p>
            </TipBox>
          </Section>
          
          <Section title="How to Use This Guide">
            <p>
              This guide is designed to support you throughout your novel-writing journey, from initial concept to completed manuscript. Here's how to get the most from it:
            </p>
            
            <ul className="list-disc pl-6 space-y-2">
              <li><strong>Read sequentially or selectively:</strong> While the sections build on each other, you can also jump to specific topics based on your current needs.</li>
              <li><strong>Try the exercises:</strong> Practical application reinforces learning and generates material for your novel.</li>
              <li><strong>Adapt the approaches:</strong> Modify techniques to suit your writing style and project needs.</li>
              <li><strong>Revisit sections:</strong> Return to relevant sections as you progress through different phases of your novel.</li>
              <li><strong>Use the self-reflection questions:</strong> These help you identify strengths, challenges, and next steps in your writing process.</li>
            </ul>
            
            <p>
              Remember that this guide is a resource, not a rulebook. The "right" way to write your novel is the way that works for you and your story.
            </p>
          </Section>
          
          <Section title="The Writer's Mindset">
            <p>
              Before diving into techniques and strategies, let's address the foundation of successful novel writing: your mindset. The attitudes and beliefs you bring to your writing significantly impact your experience and results.
            </p>
            
            <p>
              Cultivating these mindset elements will support your novel-writing journey:
            </p>
            
            <ul className="list-disc pl-6 space-y-2">
              <li><strong>Patience:</strong> Novels take time. Embrace the gradual unfolding of your story and skills.</li>
              <li><strong>Persistence:</strong> Commit to continuing despite challenges, doubts, and setbacks.</li>
              <li><strong>Curiosity:</strong> Approach your story, characters, and writing process with open-minded exploration.</li>
              <li><strong>Courage:</strong> Be willing to write imperfectly, take creative risks, and share your work.</li>
              <li><strong>Self-compassion:</strong> Treat yourself with the kindness and understanding you'd offer a friend.</li>
            </ul>
            
            <p>
              Throughout this guide, we'll explore specific strategies for developing these mindset qualities alongside your writing skills.
            </p>
            
            <Quote 
              text="The first draft is just you telling yourself the story."
              author="Terry Pratchett"
            />
            
            <p>
              With this foundation in place, let's begin exploring the practical aspects of novel writing, starting with the essential elements that form the core of every successful story.
            </p>
            
            <p>
              In the following sections, we'll dive deeper into each aspect of the novel-writing process, providing detailed guidance, practical techniques, and supportive strategies to help you bring your unique story to life.
            </p>
          </Section>
        </div>
        
        <div className="lg:col-span-1">
          <Sidebar links={sidebarLinks} />
        </div>
      </div>
    </Layout>
  );
}
