import Layout from '@/components/ui/layout';
import { Section, Quote, TipBox, Exercise, Sidebar } from '@/components/ui/content-blocks';

export default function Page() {
  const sidebarLinks = [
    { title: 'The Revision Process', href: '#the-revision-process' },
    { title: 'Self-Editing Techniques', href: '#self-editing-techniques' },
    { title: 'Common Writing Issues', href: '#common-writing-issues' },
    { title: 'Working with Feedback', href: '#working-with-feedback' },
    { title: 'Polishing Your Manuscript', href: '#polishing-your-manuscript' }
  ];

  return (
    <Layout>
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
        <div className="lg:col-span-3">
          <h1 className="text-4xl font-bold text-slate-900 mb-6">Editing and Revision</h1>
          
          <Section title="The Revision Process">
            <p>
              Revision is where the magic of writing truly happens. The first draft is about exploration and discovery—getting your story onto the page. Revision is about refining that raw material into a polished novel that effectively communicates your vision to readers.
            </p>
            
            <p>
              Successful revision requires a shift in perspective. You must transform from creator to critic, examining your work with fresh eyes and a willingness to make significant changes when necessary.
            </p>
            
            <h3 className="text-xl font-semibold mt-6 mb-3">The Purpose of Revision</h3>
            
            <p>
              Revision serves several essential functions:
            </p>
            
            <ul className="list-disc pl-6 space-y-2 my-4">
              <li>
                <strong>Clarifies your vision:</strong> Helps you identify and strengthen what your story is truly about.
              </li>
              <li>
                <strong>Enhances structure:</strong> Improves the organization and flow of your narrative.
              </li>
              <li>
                <strong>Deepens character development:</strong> Makes your characters more complex and consistent.
              </li>
              <li>
                <strong>Tightens prose:</strong> Eliminates unnecessary words and sharpens your language.
              </li>
              <li>
                <strong>Strengthens themes:</strong> Develops and reinforces your novel's central ideas.
              </li>
              <li>
                <strong>Fixes inconsistencies:</strong> Resolves contradictions and logical problems.
              </li>
              <li>
                <strong>Polishes presentation:</strong> Corrects grammar, spelling, and formatting issues.
              </li>
            </ul>
            
            <Quote 
              text="The first draft is just you telling yourself the story. Revision is where you craft that story for others."
              author="Terry Pratchett"
            />
            
            <h3 className="text-xl font-semibold mt-6 mb-3">Approaching Revision Strategically</h3>
            
            <p>
              Effective revision is a systematic process:
            </p>
            
            <ol className="list-decimal pl-6 space-y-2 my-4">
              <li>
                <strong>Create distance:</strong> Set your manuscript aside for at least a few weeks before beginning revision. This helps you see it with fresh eyes.
              </li>
              <li>
                <strong>Read through completely:</strong> Before making any changes, read your entire manuscript to get a holistic view of its strengths and weaknesses.
              </li>
              <li>
                <strong>Develop a revision plan:</strong> Identify the major issues that need addressing and prioritize them.
              </li>
              <li>
                <strong>Work in passes:</strong> Address different aspects of your novel in separate revision passes rather than trying to fix everything at once.
              </li>
              <li>
                <strong>Start with big-picture issues:</strong> Focus on structure, plot, and character before moving to sentence-level concerns.
              </li>
              <li>
                <strong>Track changes:</strong> Keep a record of significant revisions to help you maintain consistency.
              </li>
              <li>
                <strong>Seek feedback at appropriate stages:</strong> Get input from others when you've addressed the issues you can identify yourself.
              </li>
            </ol>
            
            <h3 className="text-xl font-semibold mt-6 mb-3">Revision Passes</h3>
            
            <p>
              Consider organizing your revision into these focused passes:
            </p>
            
            <ul className="list-disc pl-6 space-y-2 my-4">
              <li>
                <strong>Structural pass:</strong> Evaluate and adjust the overall organization of your novel, including chapter arrangement, scene order, and narrative arc.
              </li>
              <li>
                <strong>Plot pass:</strong> Examine your story's logic, pacing, tension, and resolution of plot threads.
              </li>
              <li>
                <strong>Character pass:</strong> Focus on character development, motivation, consistency, and arcs.
              </li>
              <li>
                <strong>Setting pass:</strong> Enhance your world-building, sensory details, and integration of setting with plot.
              </li>
              <li>
                <strong>Scene pass:</strong> Evaluate each scene for purpose, conflict, and forward momentum.
              </li>
              <li>
                <strong>Dialogue pass:</strong> Refine character voices, improve dialogue flow, and ensure conversations serve multiple purposes.
              </li>
              <li>
                <strong>Language pass:</strong> Strengthen your prose, eliminate repetition, and enhance imagery.
              </li>
              <li>
                <strong>Line-editing pass:</strong> Polish sentences for clarity, rhythm, and impact.
              </li>
              <li>
                <strong>Proofreading pass:</strong> Correct grammar, spelling, punctuation, and formatting.
              </li>
            </ul>
            
            <TipBox title="Revision Mindset">
              <p>
                Approach revision with these attitudes:
              </p>
              <ul className="list-disc pl-5 space-y-1 mt-2">
                <li>Be willing to make significant changes, including cutting beloved passages</li>
                <li>Focus on what serves the story, not your ego</li>
                <li>View revision as discovery rather than correction</li>
                <li>Celebrate the improvement process rather than seeing it as fixing failures</li>
                <li>Be patient—thorough revision takes time</li>
                <li>Trust that your story will emerge stronger through the process</li>
              </ul>
            </TipBox>
          </Section>
          
          <Section title="Self-Editing Techniques">
            <p>
              Self-editing requires developing the ability to read your own work objectively and identify areas for improvement. These techniques can help you gain the necessary perspective.
            </p>
            
            <h3 className="text-xl font-semibold mt-6 mb-3">Creating Distance</h3>
            
            <p>
              To edit effectively, you need to separate yourself from your writing:
            </p>
            
            <ul className="list-disc pl-6 space-y-2 my-4">
              <li>
                <strong>Time away:</strong> Set your manuscript aside for at least a few weeks before revising.
              </li>
              <li>
                <strong>Format changes:</strong> Read your work in a different format (printed vs. digital, different font or layout).
              </li>
              <li>
                <strong>Read aloud:</strong> Hearing your words reveals issues that silent reading might miss.
              </li>
              <li>
                <strong>Text-to-speech:</strong> Have your computer read your manuscript to you.
              </li>
              <li>
                <strong>Backward reading:</strong> Read scenes or chapters in reverse order to focus on each in isolation.
              </li>
              <li>
                <strong>Character filter:</strong> Read through the perspective of a single character to check consistency.
              </li>
            </ul>
            
            <h3 className="text-xl font-semibold mt-6 mb-3">Analytical Tools</h3>
            
            <p>
              These tools help you analyze different aspects of your novel:
            </p>
            
            <ul className="list-disc pl-6 space-y-2 my-4">
              <li>
                <strong>Scene list:</strong> Create a spreadsheet or list of all scenes with their purpose, POV, timeline, and emotional arc.
              </li>
              <li>
                <strong>Character tracker:</strong> Document character appearances, development, and consistency.
              </li>
              <li>
                <strong>Timeline:</strong> Map the chronology of your story to check for inconsistencies.
              </li>
              <li>
                <strong>Story arc diagram:</strong> Visualize your novel's tension and emotional progression.
              </li>
              <li>
                <strong>Theme tracker:</strong> Identify where and how your themes are developed throughout the manuscript.
              </li>
              <li>
                <strong>Word frequency analysis:</strong> Use software to identify overused words and phrases.
              </li>
            </ul>
            
            <h3 className="text-xl font-semibold mt-6 mb-3">Targeted Revision Strategies</h3>
            
            <p>
              These approaches help you focus on specific aspects of your novel:
            </p>
            
            <h4 className="text-lg font-medium mt-4 mb-2">For Plot and Structure:</h4>
            
            <ul className="list-disc pl-6 space-y-1 my-2">
              <li>Create a chapter-by-chapter or scene-by-scene outline of your completed draft</li>
              <li>Identify the central conflict in each scene and how it advances the overall story</li>
              <li>Check that each scene creates consequences that affect what follows</li>
              <li>Verify that plot threads are resolved and Chekhov's guns are fired</li>
              <li>Examine your pacing by noting the emotional intensity of each chapter</li>
            </ul>
            
            <h4 className="text-lg font-medium mt-4 mb-2">For Character Development:</h4>
            
            <ul className="list-disc pl-6 space-y-1 my-2">
              <li>Track each character's appearances and development throughout the manuscript</li>
              <li>Verify that character motivations are clear and consistent</li>
              <li>Check that character actions align with their established personalities</li>
              <li>Ensure character arcs progress logically and reach satisfying conclusions</li>
              <li>Confirm that dialogue reflects each character's unique voice</li>
            </ul>
            
            <h4 className="text-lg font-medium mt-4 mb-2">For Prose and Style:</h4>
            
            <ul className="list-disc pl-6 space-y-1 my-2">
              <li>Highlight adverbs and replace weak verb-adverb combinations with stronger verbs</li>
              <li>Identify passive voice and convert to active where appropriate</li>
              <li>Check for sentence variety in length and structure</li>
              <li>Look for opportunities to replace generic descriptions with specific details</li>
              <li>Eliminate redundancies and unnecessary words</li>
            </ul>
            
            <Exercise title="Targeted Revision Exercise">
              <p>Choose a chapter from your manuscript and apply these focused revision techniques:</p>
              <ol className="list-decimal pl-6 space-y-1 mt-2">
                <li>Highlight all instances of "was," "were," "is," "are" to identify potential passive voice</li>
                <li>Circle all adverbs (words ending in -ly) and evaluate if they can be replaced</li>
                <li>Underline all dialogue tags other than "said" and "asked" and consider if they're necessary</li>
                <li>Put a star next to sentences longer than three lines and consider breaking them up</li>
                <li>Put a checkmark next to each paragraph that includes sensory details beyond sight</li>
                <li>Draw a box around any clichés or generic descriptions that could be more specific</li>
              </ol>
              <p className="mt-3">
                This visual approach helps you identify patterns in your writing and areas for improvement.
              </p>
            </Exercise>
          </Section>
          
          <Section title="Common Writing Issues">
            <p>
              Certain writing problems appear frequently in early drafts. Learning to recognize and address these common issues will strengthen your manuscript significantly.
            </p>
            
            <h3 className="text-xl font-semibold mt-6 mb-3">Structural Problems</h3>
            
            <ul className="list-disc pl-6 space-y-2 my-4">
              <li>
                <strong>Slow or confusing beginning:</strong> The story takes too long to engage readers or establish what's at stake.
                <p className="mt-1 text-sm"><strong>Solution:</strong> Start closer to the inciting incident or clarify the protagonist's situation and desires earlier.</p>
              </li>
              <li>
                <strong>Sagging middle:</strong> The middle section loses momentum or wanders without clear direction.
                <p className="mt-1 text-sm"><strong>Solution:</strong> Add complications, raise stakes, or introduce a significant twist or revelation.</p>
              </li>
              <li>
                <strong>Rushed or anticlimactic ending:</strong> The conclusion feels hasty or fails to deliver emotional satisfaction.
                <p className="mt-1 text-sm"><strong>Solution:</strong> Ensure the climax addresses the central conflict and provide adequate resolution for emotional closure.</p>
              </li>
              <li>
                <strong>Episodic plot:</strong> The story feels like a series of disconnected events rather than a cohesive narrative.
                <p className="mt-1 text-sm"><strong>Solution:</strong> Strengthen cause-and-effect relationships between scenes and ensure events build toward a clear climax.</p>
              </li>
            </ul>
            
            <h3 className="text-xl font-semibold mt-6 mb-3">Character Issues</h3>
            
            <ul className="list-disc pl-6 space-y-2 my-4">
              <li>
                <strong>Passive protagonist:</strong> The main character reacts to events but doesn't drive the story through their choices.
                <p className="mt-1 text-sm"><strong>Solution:</strong> Give your protagonist agency by having them make significant decisions that affect the plot.</p>
              </li>
              <li>
                <strong>Flat or inconsistent characters:</strong> Characters lack depth or behave in ways that contradict their established traits.
                <p className="mt-1 text-sm"><strong>Solution:</strong> Develop characters' backgrounds, motivations, and internal conflicts; ensure their actions align with their personalities.</p>
              </li>
              <li>
                <strong>Indistinguishable characters:</strong> Multiple characters sound and act too similarly.
                <p className="mt-1 text-sm"><strong>Solution:</strong> Give each character distinctive speech patterns, values, reactions, and quirks.</p>
              </li>
              <li>
                <strong>Unmotivated actions:</strong> Characters do things to serve the plot rather than because of clear internal motivation.
                <p className="mt-1 text-sm"><strong>Solution:</strong> Establish clear motivations for significant character decisions and ensure they align with established character traits.</p>
              </li>
            </ul>
            
            <h3 className="text-xl font-semibold mt-6 mb-3">Prose Problems</h3>
            
            <ul className="list-disc pl-6 space-y-2 my-4">
              <li>
                <strong>Show vs. tell imbalance:</strong> Too much telling (summarizing) when showing (scene) would be more effective, or vice versa.
                <p className="mt-1 text-sm"><strong>Solution:</strong> Show important emotional moments and character development; tell when summarizing less critical information.</p>
              </li>
              <li>
                <strong>Overwriting:</strong> Excessive description, explanation, or flowery language that slows pace and tests reader patience.
                <p className="mt-1 text-sm"><strong>Solution:</strong> Cut unnecessary words, focus on specific details rather than exhaustive description, and vary descriptive intensity based on scene importance.</p>
              </li>
              <li>
                <strong>Repetitive patterns:</strong> Overused words, phrases, sentence structures, or character gestures.
                <p className="mt-1 text-sm"><strong>Solution:</strong> Identify patterns through word frequency analysis and conscious reading; vary your language and expressions.</p>
              </li>
              <li>
                <strong>Awkward dialogue:</strong> Conversations that sound unnatural, include too much exposition, or don't reflect character voices.
                <p className="mt-1 text-sm"><strong>Solution:</strong> Read dialogue aloud, cut unnecessary exposition, and ensure each character has a distinctive voice.</p>
              </li>
            </ul>
            
            <Quote 
              text="The difference between the right word and the almost right word is the difference between lightning and a lightning bug."
              author="Mark Twain"
            />
            
            <h3 className="text-xl font-semibold mt-6 mb-3">Narrative Issues</h3>
            
            <ul className="list-disc pl-6 space-y-2 my-4">
              <li>
                <strong>Inconsistent point of view:</strong> Unintentional shifts in narrative perspective or distance.
                <p className="mt-1 text-sm"><strong>Solution:</strong> Decide on your POV approach and maintain consistency; mark POV shifts clearly with scene or chapter breaks.</p>
              </li>
              <li>
                <strong>Information dumps:</strong> Large blocks of exposition or backstory that interrupt narrative flow.
                <p className="mt-1 text-sm"><strong>Solution:</strong> Integrate necessary information gradually through dialogue, character thoughts, or relevant action.</p>
              </li>
              <li>
                <strong>Unclear stakes:</strong> Readers don't understand what characters stand to gain or lose.
                <p className="mt-1 text-sm"><strong>Solution:</strong> Clearly establish what's at risk for your characters on both external and emotional levels.</p>
              </li>
              <li>
                <strong>Unearned emotional moments:</strong> Significant emotional beats that lack sufficient buildup or foundation.
                <p className="mt-1 text-sm"><strong>Solution:</strong> Develop the groundwork for emotional payoffs through earlier character development and foreshadowing.</p>
              </li>
            </ul>
            
            <TipBox title="Problem-Solving Approach">
              <p>
                When addressing issues in your manuscript:
              </p>
              <ul className="list-disc pl-5 space-y-1 mt-2">
                <li>Identify the root cause rather than just the symptom</li>
                <li>Look for patterns rather than isolated instances</li>
                <li>Consider multiple solutions before implementing changes</li>
                <li>Make one significant change at a time to evaluate its effect</li>
                <li>Be willing to try radical solutions for persistent problems</li>
                <li>Remember that cutting is often more effective than adding</li>
              </ul>
            </TipBox>
          </Section>
          
          <Section title="Working with Feedback">
            <p>
              External feedback is invaluable for identifying blind spots in your writing. Learning how to obtain, evaluate, and implement feedback effectively is a crucial skill for novelists.
            </p>
            
            <h3 className="text-xl font-semibold mt-6 mb-3">Finding the Right Readers</h3>
            
            <p>
              Different types of readers provide different kinds of feedback:
            </p>
            
            <ul className="list-disc pl-6 space-y-2 my-4">
              <li>
                <strong>Beta readers:</strong> Regular readers who represent your target audience and provide general impressions.
              </li>
              <li>
                <strong>Critique partners:</strong> Fellow writers who can offer more technical feedback on craft elements.
              </li>
              <li>
                <strong>Writing groups:</strong> Provide diverse perspectives and ongoing support through the revision process.
              </li>
              <li>
                <strong>Professional editors:</strong> Offer expert guidance on various aspects of your manuscript, from developmental issues to line editing.
              </li>
              <li>
                <strong>Sensitivity readers:</strong> Provide feedback on authentic representation of experiences outside your own.
              </li>
            </ul>
            
            <p>
              When seeking feedback, consider:
            </p>
            
            <ul className="list-disc pl-6 space-y-2 my-4">
              <li>
                <strong>Readers familiar with your genre:</strong> They understand conventions and expectations.
              </li>
              <li>
                <strong>A mix of supportive and critical readers:</strong> Balance encouragement with constructive criticism.
              </li>
              <li>
                <strong>Readers who will be honest:</strong> Polite praise doesn't help you improve.
              </li>
              <li>
                <strong>People who aren't too close to you:</strong> Friends and family may struggle to provide objective feedback.
              </li>
            </ul>
            
            <h3 className="text-xl font-semibold mt-6 mb-3">Requesting Effective Feedback</h3>
            
            <p>
              Guide your readers to provide the most helpful feedback:
            </p>
            
            <ul className="list-disc pl-6 space-y-2 my-4">
              <li>
                <strong>Be specific about what you need:</strong> General feedback ("What did you think?") yields general responses.
              </li>
              <li>
                <strong>Ask targeted questions:</strong> "Did the protagonist's motivation seem clear?" "Was the ending satisfying?"
              </li>
              <li>
                <strong>Identify areas of concern:</strong> Let readers know if you're struggling with particular elements.
              </li>
              <li>
                <strong>Specify the type of feedback:</strong> Developmental, character-focused, pacing, prose style, etc.
              </li>
              <li>
                <strong>Clarify the manuscript's stage:</strong> Early drafts need different feedback than nearly finished ones.
              </li>
              <li>
                <strong>Provide context:</strong> Share your intentions for the work to help readers evaluate how well you've achieved them.
              </li>
            </ul>
            
            <h3 className="text-xl font-semibold mt-6 mb-3">Processing Feedback</h3>
            
            <p>
              Receiving criticism can be emotionally challenging. These strategies help:
            </p>
            
            <ul className="list-disc pl-6 space-y-2 my-4">
              <li>
                <strong>Separate yourself from your work:</strong> Feedback is about the manuscript, not you.
              </li>
              <li>
                <strong>Listen without defending:</strong> Resist the urge to explain or justify when receiving feedback.
              </li>
              <li>
                <strong>Look for patterns:</strong> Pay special attention when multiple readers identify the same issue.
              </li>
              <li>
                <strong>Consider the source:</strong> Weigh feedback based on the reader's expertise and understanding of your goals.
              </li>
              <li>
                <strong>Sit with feedback before responding:</strong> Allow your emotional reaction to settle before deciding what to implement.
              </li>
              <li>
                <strong>Focus on problems, not solutions:</strong> Readers are good at identifying what doesn't work but may not offer the best fix.
              </li>
            </ul>
            
            <Exercise title="Feedback Processing Worksheet">
              <p>After receiving feedback, organize it using this approach:</p>
              <ol className="list-decimal pl-6 space-y-1 mt-2">
                <li>List issues mentioned by multiple readers (highest priority)</li>
                <li>List issues mentioned by your most trusted/expert readers</li>
                <li>List issues that resonated with you immediately</li>
                <li>List suggestions that conflict with each other or with your vision</li>
                <li>For each issue you plan to address, brainstorm multiple possible solutions</li>
                <li>Develop an action plan prioritizing the most significant issues</li>
              </ol>
              <p className="mt-3">
                This systematic approach helps you make the most of feedback while maintaining your authorial vision.
              </p>
            </Exercise>
          </Section>
          
          <Section title="Polishing Your Manuscript">
            <p>
              The final stages of revision focus on refining your prose and preparing your manuscript for its audience. This polishing phase transforms a good manuscript into a great one.
            </p>
            
            <h3 className="text-xl font-semibold mt-6 mb-3">Line Editing</h3>
            
            <p>
              Line editing focuses on the craft of your prose at the sentence level:
            </p>
            
            <ul className="list-disc pl-6 space-y-2 my-4">
              <li>
                <strong>Enhance clarity:</strong> Ensure each sentence communicates exactly what you intend.
              </li>
              <li>
                <strong>Improve flow:</strong> Create smooth transitions between sentences and paragraphs.
              </li>
              <li>
                <strong>Strengthen imagery:</strong> Replace generic descriptions with specific, vivid details.
              </li>
              <li>
                <strong>Tighten language:</strong> Eliminate unnecessary words and phrases that dilute your prose.
              </li>
              <li>
                <strong>Vary rhythm:</strong> Create a pleasing cadence through sentence length and structure variation.
              </li>
              <li>
                <strong>Enhance voice:</strong> Refine your prose to reflect your unique authorial voice.
              </li>
            </ul>
            
            <h3 className="text-xl font-semibold mt-6 mb-3">Common Line-Level Issues</h3>
            
            <p>
              Watch for these frequent problems during line editing:
            </p>
            
            <ul className="list-disc pl-6 space-y-2 my-4">
              <li>
                <strong>Weak verbs:</strong> Generic verbs that could be replaced with more specific, vivid options.
                <p className="mt-1 text-sm"><strong>Example:</strong> "She walked across the room" → "She strode/shuffled/tiptoed across the room"</p>
              </li>
              <li>
                <strong>Overuse of adverbs:</strong> Relying on adverbs rather than choosing stronger verbs.
                <p className="mt-1 text-sm"><strong>Example:</strong> "He ran quickly" → "He sprinted/dashed/raced"</p>
              </li>
              <li>
                <strong>Redundancies:</strong> Phrases that repeat information unnecessarily.
                <p className="mt-1 text-sm"><strong>Example:</strong> "She nodded her head in agreement" → "She nodded"</p>
              </li>
              <li>
                <strong>Empty intensifiers:</strong> Words like "very," "really," "quite" that add little meaning.
                <p className="mt-1 text-sm"><strong>Example:</strong> "He was very tired" → "He was exhausted"</p>
              </li>
              <li>
                <strong>Filtering:</strong> Unnecessarily filtering experiences through character perception.
                <p className="mt-1 text-sm"><strong>Example:</strong> "She saw the door open" → "The door opened"</p>
              </li>
              <li>
                <strong>Telling tags:</strong> Emotional states that could be shown through action or dialogue.
                <p className="mt-1 text-sm"><strong>Example:</strong> "She was angry" → "She slammed her fist on the table"</p>
              </li>
              <li>
                <strong>Overused words:</strong> Pet words and phrases that appear too frequently.
                <p className="mt-1 text-sm"><strong>Solution:</strong> Use word frequency analysis to identify and vary repetitive language</p>
              </li>
            </ul>
            
            <h3 className="text-xl font-semibold mt-6 mb-3">Copyediting and Proofreading</h3>
            
            <p>
              The final technical review of your manuscript addresses:
            </p>
            
            <ul className="list-disc pl-6 space-y-2 my-4">
              <li>
                <strong>Grammar and syntax:</strong> Correct grammatical errors and awkward constructions.
              </li>
              <li>
                <strong>Spelling:</strong> Fix misspelled words and typos.
              </li>
              <li>
                <strong>Punctuation:</strong> Ensure proper use of commas, semicolons, quotation marks, etc.
              </li>
              <li>
                <strong>Consistency:</strong> Maintain consistent spelling, capitalization, and formatting.
              </li>
              <li>
                <strong>Factual accuracy:</strong> Verify that any factual information is correct.
              </li>
              <li>
                <strong>Formatting:</strong> Check that the manuscript follows standard formatting conventions.
              </li>
            </ul>
            
            <TipBox title="Proofreading Techniques">
              <p>
                To catch errors in your final draft:
              </p>
              <ul className="list-disc pl-5 space-y-1 mt-2">
                <li>Read your manuscript backward, sentence by sentence</li>
                <li>Change the font, size, or color to make errors more visible</li>
                <li>Read a printed copy rather than on-screen</li>
                <li>Use text-to-speech to hear problems your eyes might miss</li>
                <li>Focus on one type of error at a time (e.g., just commas, just dialogue formatting)</li>
                <li>Take breaks to maintain focus and attention to detail</li>
                <li>Consider professional copyediting for the final polish</li>
              </ul>
            </TipBox>
            
            <h3 className="text-xl font-semibold mt-6 mb-3">Knowing When You're Done</h3>
            
            <p>
              One of the greatest challenges for writers is determining when a manuscript is truly finished. Consider these indicators:
            </p>
            
            <ul className="list-disc pl-6 space-y-2 my-4">
              <li>
                <strong>Diminishing returns:</strong> Your revisions are making the manuscript different but not necessarily better.
              </li>
              <li>
                <strong>Consistent feedback:</strong> Beta readers and critique partners are no longer identifying significant issues.
              </li>
              <li>
                <strong>Technical polish:</strong> The manuscript is free of grammatical errors, typos, and formatting issues.
              </li>
              <li>
                <strong>Narrative integrity:</strong> The story feels complete and cohesive from beginning to end.
              </li>
              <li>
                <strong>Personal satisfaction:</strong> You've addressed all the issues that concerned you about the manuscript.
              </li>
              <li>
                <strong>Professional assessment:</strong> If you've worked with an editor, they agree the manuscript is ready.
              </li>
            </ul>
            
            <Quote 
              text="Art is never finished, only abandoned."
              author="Leonardo da Vinci"
            />
            
            <p>
              Remember that perfect is the enemy of done. At some point, you must release your work and move on to the next project, taking what you've learned to continue growing as a writer.
            </p>
            
            <p className="mt-4">
              In the next section, we'll explore strategies for overcoming writer's block and maintaining momentum throughout the writing process.
            </p>
          </Section>
        </div>
        
        <div className="lg:col-span-1">
          <Sidebar links={sidebarLinks} />
        </div>
      </div>
    </Layout>
  );
}
