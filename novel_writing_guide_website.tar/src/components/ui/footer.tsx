import { Navigation } from '@/components/ui/navigation';

export default function Footer() {
  const currentYear = new Date().getFullYear();
  
  return (
    <footer className="bg-slate-800 text-white py-6 mt-12">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div>
            <h3 className="text-lg font-semibold mb-4">Novel Writing Guide</h3>
            <p className="text-slate-300">
              A comprehensive resource to help you begin and sustain your novel writing journey.
            </p>
          </div>
          <div>
            <h3 className="text-lg font-semibold mb-4">Quick Links</h3>
            <ul className="space-y-2">
              <li><a href="/" className="text-slate-300 hover:text-amber-300 transition-colors">Home</a></li>
              <li><a href="/writing-process" className="text-slate-300 hover:text-amber-300 transition-colors">Writing Process</a></li>
              <li><a href="/character-development" className="text-slate-300 hover:text-amber-300 transition-colors">Character Development</a></li>
              <li><a href="/editing-revision" className="text-slate-300 hover:text-amber-300 transition-colors">Editing & Revision</a></li>
            </ul>
          </div>
          <div>
            <h3 className="text-lg font-semibold mb-4">Resources</h3>
            <ul className="space-y-2">
              <li><a href="/self-reflection" className="text-slate-300 hover:text-amber-300 transition-colors">Self-Reflection Questions</a></li>
              <li><a href="/writers-block" className="text-slate-300 hover:text-amber-300 transition-colors">Overcoming Writer's Block</a></li>
              <li><a href="/building-confidence" className="text-slate-300 hover:text-amber-300 transition-colors">Building Confidence</a></li>
            </ul>
          </div>
        </div>
        <div className="border-t border-slate-700 mt-8 pt-6 text-center text-slate-400">
          <p>© {currentYear} Novel Writing Guide. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
}
