export interface SectionProps {
  title: string;
  children: React.ReactNode;
}

export function Section({ title, children }: SectionProps) {
  // Create an ID from the title for anchor links
  const id = title.toLowerCase().replace(/\s+/g, '-').replace(/[^\w-]/g, '');
  
  return (
    <section id={id} className="mb-12">
      <h2 className="text-2xl font-bold text-slate-800 mb-4 pb-2 border-b border-slate-200">
        {title}
      </h2>
      <div className="prose prose-slate max-w-none">
        {children}
      </div>
    </section>
  );
}

export interface QuoteProps {
  text: string;
  author?: string;
}

export function Quote({ text, author }: QuoteProps) {
  return (
    <blockquote className="border-l-4 border-amber-400 pl-4 py-2 my-6 bg-amber-50 rounded">
      <p className="italic text-slate-700">{text}</p>
      {author && <footer className="text-right text-sm text-slate-500 mt-1">— {author}</footer>}
    </blockquote>
  );
}

export interface TipBoxProps {
  title: string;
  children: React.ReactNode;
}

export function TipBox({ title, children }: TipBoxProps) {
  return (
    <div className="bg-blue-50 border-l-4 border-blue-500 p-4 my-6 rounded">
      <h4 className="text-lg font-semibold text-blue-700 mb-2">{title}</h4>
      <div className="text-slate-700">
        {children}
      </div>
    </div>
  );
}

export interface ExerciseProps {
  title: string;
  children: React.ReactNode;
}

export function Exercise({ title, children }: ExerciseProps) {
  return (
    <div className="bg-green-50 border border-green-200 p-4 my-6 rounded">
      <h4 className="text-lg font-semibold text-green-700 mb-2">
        Exercise: {title}
      </h4>
      <div className="text-slate-700">
        {children}
      </div>
    </div>
  );
}

export interface SidebarProps {
  links: {
    title: string;
    href: string;
  }[];
}

export function Sidebar({ links }: SidebarProps) {
  return (
    <div className="bg-slate-50 p-4 rounded-lg sticky top-4">
      <h3 className="text-lg font-semibold mb-3 text-slate-700">In This Section</h3>
      <ul className="space-y-2">
        {links.map((link) => (
          <li key={link.href}>
            <a 
              href={link.href} 
              className="text-slate-600 hover:text-amber-600 transition-colors"
            >
              {link.title}
            </a>
          </li>
        ))}
      </ul>
    </div>
  );
}
