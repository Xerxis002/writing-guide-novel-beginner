import Layout from '@/components/ui/layout';
import { Section, Quote, TipBox, Exercise, Sidebar } from '@/components/ui/content-blocks';

export default function Page() {
  const sidebarLinks = [
    { title: 'World-Building Fundamentals', href: '#world-building-fundamentals' },
    { title: 'Creating Immersive Settings', href: '#creating-immersive-settings' },
    { title: 'Developing Cultures and Societies', href: '#developing-cultures-and-societies' },
    { title: 'World Rules and Systems', href: '#world-rules-and-systems' },
    { title: 'Integrating Setting with Story', href: '#integrating-setting-with-story' }
  ];

  return (
    <Layout>
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
        <div className="lg:col-span-3">
          <h1 className="text-4xl font-bold text-slate-900 mb-6">World Building</h1>
          
          <Section title="World-Building Fundamentals">
            <p>
              World-building is the process of constructing the setting where your novel takes place. Whether you're creating a fictional universe for fantasy or science fiction, or developing a realistic contemporary setting, thoughtful world-building creates a rich, immersive environment that enhances your story and influences your characters.
            </p>
            
            <p>
              Effective world-building goes beyond mere description—it creates a living, breathing context for your narrative that feels authentic and consistent, even when entirely imaginary.
            </p>
            
            <h3 className="text-xl font-semibold mt-6 mb-3">The Purpose of World-Building</h3>
            
            <p>
              World-building serves several important functions in your novel:
            </p>
            
            <ul className="list-disc pl-6 space-y-2 my-4">
              <li>
                <strong>Creates atmosphere and mood:</strong> The setting establishes the emotional tone of your story.
              </li>
              <li>
                <strong>Shapes character development:</strong> Characters are products of their environment and are influenced by the world around them.
              </li>
              <li>
                <strong>Generates conflict:</strong> The rules, limitations, and challenges of your world create natural sources of tension.
              </li>
              <li>
                <strong>Enhances verisimilitude:</strong> Detailed, consistent world-building makes even fantastical settings feel believable.
              </li>
              <li>
                <strong>Supports themes:</strong> The setting often reflects or reinforces the thematic elements of your story.
              </li>
            </ul>
            
            <Quote 
              text="Build your world, then let it tell you what stories it contains."
              author="N.K. Jemisin"
            />
            
            <h3 className="text-xl font-semibold mt-6 mb-3">Approaches to World-Building</h3>
            
            <p>
              There are two primary approaches to world-building, and most writers use a combination of both:
            </p>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 my-6">
              <div className="bg-blue-50 p-4 rounded">
                <h4 className="font-semibold text-blue-800 mb-2">Top-Down Approach</h4>
                <ul className="list-disc pl-5 space-y-1">
                  <li>Start with the big picture: geography, history, political systems</li>
                  <li>Develop major cultural groups and their relationships</li>
                  <li>Create rules that govern the world (physical, magical, social)</li>
                  <li>Work down to specific locations and communities</li>
                  <li>Useful for complex worlds with multiple cultures or unusual physics</li>
                </ul>
              </div>
              
              <div className="bg-green-50 p-4 rounded">
                <h4 className="font-semibold text-green-800 mb-2">Bottom-Up Approach</h4>
                <ul className="list-disc pl-5 space-y-1">
                  <li>Start with the immediate setting of your story</li>
                  <li>Develop details relevant to your characters and plot</li>
                  <li>Expand outward as the story requires</li>
                  <li>Add history and broader context as needed</li>
                  <li>Efficient for stories with a limited scope or contemporary settings</li>
                </ul>
              </div>
            </div>
            
            <p>
              The best approach depends on your story's needs and your personal writing style. Many writers combine elements of both, starting with essential world elements and expanding as the narrative develops.
            </p>
          </Section>
          
          <Section title="Creating Immersive Settings">
            <p>
              An immersive setting engages all the senses and makes readers feel as if they're experiencing the world alongside your characters. The key is to provide specific, vivid details that bring your setting to life.
            </p>
            
            <h3 className="text-xl font-semibold mt-6 mb-3">Physical Environment</h3>
            
            <p>
              Consider these aspects of your physical setting:
            </p>
            
            <ul className="list-disc pl-6 space-y-2 my-4">
              <li>
                <strong>Geography:</strong> Landscapes, terrain, bodies of water, climate zones
              </li>
              <li>
                <strong>Natural features:</strong> Flora, fauna, natural resources, weather patterns
              </li>
              <li>
                <strong>Built environment:</strong> Architecture, infrastructure, technology level
              </li>
              <li>
                <strong>Spatial relationships:</strong> Distances between locations, travel methods and times
              </li>
              <li>
                <strong>Sensory details:</strong> Sights, sounds, smells, textures, and tastes unique to your setting
              </li>
            </ul>
            
            <TipBox title="Sensory World-Building">
              <p>
                When describing settings, engage all five senses:
              </p>
              <ul className="list-disc pl-5 space-y-1 mt-2">
                <li><strong>Sight:</strong> Colors, light quality, visual textures, movement</li>
                <li><strong>Sound:</strong> Ambient noise, voices, music, silence, acoustics</li>
                <li><strong>Smell:</strong> Aromas, stenches, subtle scents that characterize a place</li>
                <li><strong>Touch:</strong> Temperatures, textures, air quality, physical sensations</li>
                <li><strong>Taste:</strong> Local foods, drinks, or even the taste of the air</li>
              </ul>
              <p className="mt-2">
                Focus on distinctive details that characterize your setting rather than cataloging every element.
              </p>
            </TipBox>
            
            <h3 className="text-xl font-semibold mt-6 mb-3">Temporal Setting</h3>
            
            <p>
              Your setting exists not just in space but in time:
            </p>
            
            <ul className="list-disc pl-6 space-y-2 my-4">
              <li>
                <strong>Historical period:</strong> The era in which your story takes place
              </li>
              <li>
                <strong>Seasonal cycles:</strong> How the setting changes with seasons
              </li>
              <li>
                <strong>Daily rhythms:</strong> How the setting transforms from day to night
              </li>
              <li>
                <strong>Historical context:</strong> Past events that shaped the current state of your world
              </li>
              <li>
                <strong>Rate of change:</strong> How quickly technology, culture, or the environment is evolving
              </li>
            </ul>
            
            <Exercise title="Setting Sketch">
              <p>Choose a key location in your novel and write a brief sketch that:</p>
              <ol className="list-decimal pl-6 space-y-1 mt-2">
                <li>Includes at least one detail for each of the five senses</li>
                <li>Shows how the location changes at different times (day/night, seasons, etc.)</li>
                <li>Reveals something about the people who inhabit or use this space</li>
                <li>Hints at the history or significance of the place</li>
                <li>Creates a specific mood or atmosphere</li>
              </ol>
              <p className="mt-3">
                This exercise helps you develop rich, multidimensional settings that serve your story.
              </p>
            </Exercise>
          </Section>
          
          <Section title="Developing Cultures and Societies">
            <p>
              Cultures and societies form the social fabric of your world. Whether you're creating alien civilizations or depicting real-world communities, thoughtful cultural development adds depth and authenticity to your setting.
            </p>
            
            <h3 className="text-xl font-semibold mt-6 mb-3">Elements of Culture</h3>
            
            <p>
              Consider these aspects when developing cultures for your world:
            </p>
            
            <ul className="list-disc pl-6 space-y-2 my-4">
              <li>
                <strong>Social structure:</strong> Class systems, hierarchies, family structures
              </li>
              <li>
                <strong>Governance:</strong> Political systems, leadership, laws and enforcement
              </li>
              <li>
                <strong>Economy:</strong> Resources, trade, currency, occupations
              </li>
              <li>
                <strong>Beliefs:</strong> Religion, philosophy, values, taboos
              </li>
              <li>
                <strong>Customs:</strong> Traditions, rituals, celebrations, daily practices
              </li>
              <li>
                <strong>Arts:</strong> Music, visual arts, literature, performance
              </li>
              <li>
                <strong>Language:</strong> Communication methods, dialects, slang, written forms
              </li>
              <li>
                <strong>Technology:</strong> Tools, innovations, relationship with technology
              </li>
            </ul>
            
            <h3 className="text-xl font-semibold mt-6 mb-3">Cultural Complexity</h3>
            
            <p>
              Avoid creating monolithic cultures where everyone thinks and acts the same way. Real cultures contain:
            </p>
            
            <ul className="list-disc pl-6 space-y-2 my-4">
              <li>
                <strong>Subcultures:</strong> Groups with distinct practices within the larger culture
              </li>
              <li>
                <strong>Countercultures:</strong> Groups that actively oppose dominant cultural norms
              </li>
              <li>
                <strong>Regional variations:</strong> Differences based on geography or local history
              </li>
              <li>
                <strong>Generational differences:</strong> Changing values and practices across age groups
              </li>
              <li>
                <strong>Cultural evolution:</strong> How practices and beliefs change over time
              </li>
              <li>
                <strong>Individual variation:</strong> How individuals conform to or deviate from cultural norms
              </li>
            </ul>
            
            <Quote 
              text="Culture is the widening of the mind and of the spirit."
              author="Jawaharlal Nehru"
            />
            
            <h3 className="text-xl font-semibold mt-6 mb-3">Cultural Interaction</h3>
            
            <p>
              When multiple cultures exist in your world, consider how they interact:
            </p>
            
            <ul className="list-disc pl-6 space-y-2 my-4">
              <li>
                <strong>Trade and exchange:</strong> Economic relationships and material exchange
              </li>
              <li>
                <strong>Conflict:</strong> Historical or current tensions, wars, territorial disputes
              </li>
              <li>
                <strong>Cultural diffusion:</strong> How ideas, practices, and technologies spread
              </li>
              <li>
                <strong>Power dynamics:</strong> Colonization, imperialism, resistance
              </li>
              <li>
                <strong>Blending:</strong> Hybrid cultures, border regions, multicultural communities
              </li>
            </ul>
            
            <TipBox title="Cultural Research">
              <p>
                When creating fictional cultures, research real-world cultures for inspiration:
              </p>
              <ul className="list-disc pl-5 space-y-1 mt-2">
                <li>Study how real cultures adapted to similar environments</li>
                <li>Research historical societies at comparable technological levels</li>
                <li>Examine how real cultures have interacted throughout history</li>
                <li>Explore anthropological concepts like cultural universals</li>
                <li>Be mindful of cultural appropriation and stereotyping</li>
              </ul>
              <p className="mt-2">
                The goal is not to copy existing cultures but to understand the complex ways that human societies develop and function.
              </p>
            </TipBox>
          </Section>
          
          <Section title="World Rules and Systems">
            <p>
              Every world operates according to certain rules—whether they're the laws of physics, magical systems, social conventions, or technological limitations. Establishing clear, consistent rules creates a framework that makes your world feel coherent and believable.
            </p>
            
            <h3 className="text-xl font-semibold mt-6 mb-3">Types of World Rules</h3>
            
            <p>
              Consider these categories of rules for your world:
            </p>
            
            <ul className="list-disc pl-6 space-y-2 my-4">
              <li>
                <strong>Physical laws:</strong> How the natural world functions (may differ from our reality in speculative fiction)
              </li>
              <li>
                <strong>Magical or supernatural systems:</strong> Sources, limitations, and consequences of extraordinary powers
              </li>
              <li>
                <strong>Technological frameworks:</strong> Available technologies, their capabilities and limitations
              </li>
              <li>
                <strong>Social rules:</strong> Laws, customs, taboos, and expectations that govern behavior
              </li>
              <li>
                <strong>Economic systems:</strong> How resources are distributed, valued, and exchanged
              </li>
              <li>
                <strong>Power structures:</strong> How authority is established, maintained, and challenged
              </li>
            </ul>
            
            <h3 className="text-xl font-semibold mt-6 mb-3">Designing Effective Systems</h3>
            
            <p>
              Whether creating magic, technology, or social structures, follow these principles:
            </p>
            
            <ul className="list-disc pl-6 space-y-2 my-4">
              <li>
                <strong>Internal consistency:</strong> Systems should operate according to their own logic without contradictions.
              </li>
              <li>
                <strong>Limitations and costs:</strong> Every power or advantage should have meaningful limitations or costs.
              </li>
              <li>
                <strong>Integration with society:</strong> Consider how systems affect culture, economy, and power structures.
              </li>
              <li>
                <strong>Narrative potential:</strong> Systems should create opportunities for conflict and character development.
              </li>
              <li>
                <strong>Comprehensibility:</strong> Readers should be able to understand the basic principles without exhaustive explanation.
              </li>
            </ul>
            
            <Exercise title="System Development">
              <p>Design a system (magical, technological, social, etc.) for your world by answering these questions:</p>
              <ol className="list-decimal pl-6 space-y-1 mt-2">
                <li>What can this system do? What are its primary functions or effects?</li>
                <li>What can't it do? What are its limitations or boundaries?</li>
                <li>What is the cost or price of using this system?</li>
                <li>Who has access to this system and who doesn't? Why?</li>
                <li>How has this system shaped the culture and society around it?</li>
                <li>How might characters exploit or subvert this system?</li>
              </ol>
              <p className="mt-3">
                This exercise helps you create systems that feel realistic and generate interesting story possibilities.
              </p>
            </Exercise>
          </Section>
          
          <Section title="Integrating Setting with Story">
            <p>
              World-building should never exist for its own sake—it must serve your story. The most effective world-building is seamlessly integrated with plot and character development, creating a setting that feels essential rather than decorative.
            </p>
            
            <h3 className="text-xl font-semibold mt-6 mb-3">Setting as Character</h3>
            
            <p>
              In many novels, the setting functions almost like another character:
            </p>
            
            <ul className="list-disc pl-6 space-y-2 my-4">
              <li>
                <strong>It has a distinct personality</strong> with moods, quirks, and a unique presence.
              </li>
              <li>
                <strong>It actively influences the plot</strong> by creating obstacles or opportunities.
              </li>
              <li>
                <strong>It changes over time</strong> in response to events or character actions.
              </li>
              <li>
                <strong>It forms relationships with characters</strong> who may love, hate, fear, or feel ambivalent about it.
              </li>
              <li>
                <strong>It embodies themes</strong> through its physical or cultural characteristics.
              </li>
            </ul>
            
            <h3 className="text-xl font-semibold mt-6 mb-3">Revealing Your World</h3>
            
            <p>
              Avoid information dumps by revealing your world gradually:
            </p>
            
            <ul className="list-disc pl-6 space-y-2 my-4">
              <li>
                <strong>Show through character interaction:</strong> Reveal aspects of your world as characters navigate it.
              </li>
              <li>
                <strong>Reveal on a need-to-know basis:</strong> Introduce elements when they become relevant to the story.
              </li>
              <li>
                <strong>Use the unfamiliar viewpoint:</strong> If possible, show the world through the eyes of a character who is discovering it.
              </li>
              <li>
                <strong>Demonstrate through conflict:</strong> Reveal world rules when they create problems or solutions for characters.
              </li>
              <li>
                <strong>Imply rather than explain:</strong> Let readers infer aspects of your world from specific details.
              </li>
            </ul>
            
            <Quote 
              text="The world of a novel is not a backdrop, it's a character. And like any character, it should be complex, contradictory, and constantly evolving."
              author="Ursula K. Le Guin"
            />
            
            <h3 className="text-xl font-semibold mt-6 mb-3">The Iceberg Principle</h3>
            
            <p>
              The "iceberg principle" of world-building suggests that you should know much more about your world than you actually show to readers. Like an iceberg, where only a small portion is visible above water, your world should have depth and complexity beneath what appears on the page.
            </p>
            
            <p>
              This approach:
            </p>
            
            <ul className="list-disc pl-6 space-y-2 my-4">
              <li>
                <strong>Creates authenticity:</strong> When you know your world thoroughly, the details you choose to include feel grounded in a larger reality.
              </li>
              <li>
                <strong>Prevents inconsistencies:</strong> A well-developed background helps you maintain consistency in your world's rules and systems.
              </li>
              <li>
                <strong>Allows for discovery:</strong> Readers enjoy piecing together your world from carefully chosen details rather than having everything explained.
              </li>
              <li>
                <strong>Provides flexibility:</strong> A detailed background gives you more options when plot developments require new setting elements.
              </li>
            </ul>
            
            <TipBox title="The World-Building Ratio">
              <p>
                For every world-building detail you include in your novel, develop several more that remain in your notes. This creates depth without overwhelming readers with information.
              </p>
              <p className="mt-2">
                Remember that your goal is to tell a compelling story, not to showcase every aspect of your world. Include only the details that enhance the narrative and engage readers.
              </p>
            </TipBox>
            
            <p className="mt-4">
              In the next section, we'll explore plotting and story structure—creating a compelling narrative framework that engages readers from beginning to end.
            </p>
          </Section>
        </div>
        
        <div className="lg:col-span-1">
          <Sidebar links={sidebarLinks} />
        </div>
      </div>
    </Layout>
  );
}
