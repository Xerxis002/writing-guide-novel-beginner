import Layout from '@/components/ui/layout';
import { Section, Quote, TipBox, Exercise, Sidebar } from '@/components/ui/content-blocks';

export default function Page() {
  const sidebarLinks = [
    { title: 'Understanding the Writing Process', href: '#understanding-the-writing-process' },
    { title: 'Finding Your Writing Approach', href: '#finding-your-writing-approach' },
    { title: 'The Drafting Process', href: '#the-drafting-process' },
    { title: 'Establishing a Writing Routine', href: '#establishing-a-writing-routine' },
    { title: 'Managing Your Writing Project', href: '#managing-your-writing-project' }
  ];

  return (
    <Layout>
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
        <div className="lg:col-span-3">
          <h1 className="text-4xl font-bold text-slate-900 mb-6">The Writing Process</h1>
          
          <Section title="Understanding the Writing Process">
            <p>
              The writing process is the journey from initial idea to completed manuscript. While every writer's process is unique, understanding the common phases can help you navigate your novel-writing journey more effectively.
            </p>
            
            <p>
              Writing a novel isn't a linear path but rather a series of interconnected phases that often overlap and repeat. Recognizing these phases helps you understand where you are in your journey and what approaches might be most helpful at each stage.
            </p>
            
            <h3 className="text-xl font-semibold mt-6 mb-3">The Five Phases of Writing</h3>
            
            <ol className="list-decimal pl-6 space-y-4">
              <li>
                <strong>Ideation:</strong> Generating and developing ideas for your story. This includes brainstorming concepts, exploring themes, and imagining characters and settings.
              </li>
              <li>
                <strong>Planning:</strong> Organizing your ideas into a coherent structure. Depending on your writing style, this might involve detailed outlining or simply clarifying the core elements of your story.
              </li>
              <li>
                <strong>Drafting:</strong> Writing the actual manuscript, focusing on getting the story onto the page rather than perfection.
              </li>
              <li>
                <strong>Revising:</strong> Refining your draft through multiple rounds of revision, addressing issues of structure, character, plot, and theme.
              </li>
              <li>
                <strong>Polishing:</strong> Making final adjustments to language, style, and presentation to prepare your manuscript for readers.
              </li>
            </ol>
            
            <p className="mt-4">
              These phases rarely proceed in a strictly sequential manner. You might plan, draft, and then return to planning when you discover new aspects of your story. You might revise one chapter while still drafting another. The process is cyclical and recursive rather than linear.
            </p>
            
            <Quote 
              text="The first draft is just you telling yourself the story. The second, third, fourth, and fifth drafts are you figuring out how to tell it to other people."
              author="Patrick Rothfuss"
            />
          </Section>
          
          <Section title="Finding Your Writing Approach">
            <p>
              Writers typically fall somewhere on a spectrum between two approaches to novel writing: planning and discovery. Understanding your natural tendencies helps you develop a process that works with your creative style rather than against it.
            </p>
            
            <h3 className="text-xl font-semibold mt-6 mb-3">The Planning-Discovery Spectrum</h3>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 my-6">
              <div className="bg-blue-50 p-4 rounded">
                <h4 className="font-semibold text-blue-800 mb-2">Planners (Outliners)</h4>
                <ul className="list-disc pl-5 space-y-1">
                  <li>Prefer to map out the story before writing</li>
                  <li>Create detailed character profiles and world-building documents</li>
                  <li>Develop scene-by-scene or chapter-by-chapter outlines</li>
                  <li>Feel more secure with a roadmap</li>
                  <li>May struggle with feeling constrained by their plans</li>
                </ul>
              </div>
              
              <div className="bg-green-50 p-4 rounded">
                <h4 className="font-semibold text-green-800 mb-2">Discoverers (Pantsers)</h4>
                <ul className="list-disc pl-5 space-y-1">
                  <li>Prefer to discover the story while writing</li>
                  <li>Let characters and plot develop organically</li>
                  <li>Often start with a situation or character rather than a plot</li>
                  <li>Enjoy the surprise of unexpected story developments</li>
                  <li>May struggle with structural issues that require revision</li>
                </ul>
              </div>
            </div>
            
            <p>
              Most writers combine elements of both approaches. You might plan your major plot points but discover the details as you write. Or you might write a discovery draft and then create a structured plan for revision.
            </p>
            
            <TipBox title="Hybrid Approaches">
              <p>
                Consider these hybrid approaches that combine planning and discovery:
              </p>
              <ul className="list-disc pl-5 space-y-1 mt-2">
                <li><strong>Signpost method:</strong> Plan major turning points but discover how to get from one to the next</li>
                <li><strong>Character-driven planning:</strong> Develop detailed character profiles and motivations, then let their decisions drive the plot</li>
                <li><strong>Discovery draft followed by structured revision:</strong> Write freely for the first draft, then create a structured plan for revision</li>
                <li><strong>Scene-by-scene planning:</strong> Plan one scene at a time, just before writing it</li>
              </ul>
            </TipBox>
            
            <Exercise title="Identify Your Natural Approach">
              <p>Reflect on your natural tendencies by considering these questions:</p>
              <ol className="list-decimal pl-6 space-y-1 mt-2">
                <li>Do you prefer to know where you're going before you start, or do you enjoy discovering as you go?</li>
                <li>In other creative projects, do you plan extensively or dive in and figure it out?</li>
                <li>What feels more uncomfortable: being constrained by a plan or facing a blank page without direction?</li>
                <li>When you imagine stories, do you see the structure first or individual scenes and characters?</li>
              </ol>
              <p className="mt-3">
                There's no right or wrong answer—the goal is to understand your natural tendencies so you can work with them rather than against them.
              </p>
            </Exercise>
          </Section>
          
          <Section title="The Drafting Process">
            <p>
              Drafting is the phase where you transform your ideas into actual prose. This is often the most challenging and rewarding part of the writing process.
            </p>
            
            <h3 className="text-xl font-semibold mt-6 mb-3">First Draft Principles</h3>
            
            <p>
              The first draft has one primary purpose: to exist. Everything else—beautiful prose, perfect pacing, compelling dialogue—can be addressed in revision. These principles can help you complete your first draft:
            </p>
            
            <ul className="list-disc pl-6 space-y-2 my-4">
              <li>
                <strong>Permission to write badly:</strong> The first draft is meant to be imperfect. Give yourself permission to write awkward dialogue, clunky descriptions, and imperfect scenes.
              </li>
              <li>
                <strong>Forward momentum:</strong> Keep moving forward rather than getting stuck in endless revision of early chapters.
              </li>
              <li>
                <strong>Consistency over perfection:</strong> Regular writing, even in small amounts, is more valuable than occasional perfect sessions.
              </li>
              <li>
                <strong>Problem-solving through writing:</strong> When you encounter a plot problem, often the best solution is to keep writing and see what emerges.
              </li>
              <li>
                <strong>The power of completion:</strong> Finishing a draft, even a flawed one, is a significant achievement that teaches you about your story and yourself as a writer.
              </li>
            </ul>
            
            <Quote 
              text="The first draft is just you telling yourself the story."
              author="Terry Pratchett"
            />
            
            <h3 className="text-xl font-semibold mt-6 mb-3">Drafting Techniques</h3>
            
            <p>
              These techniques can help you maintain momentum during the drafting phase:
            </p>
            
            <ul className="list-disc pl-6 space-y-2 my-4">
              <li>
                <strong>Word count goals:</strong> Set achievable daily or weekly targets to measure progress.
              </li>
              <li>
                <strong>Timed writing sessions:</strong> Use techniques like the Pomodoro method (25 minutes of focused writing followed by a 5-minute break).
              </li>
              <li>
                <strong>Scene-by-scene approach:</strong> Focus on completing one scene at a time rather than thinking about the entire novel.
              </li>
              <li>
                <strong>Placeholder notes:</strong> When stuck on a detail, insert a note like [RESEARCH THIS LATER] and continue writing.
              </li>
              <li>
                <strong>End-of-session notes:</strong> Before finishing a writing session, make brief notes about what comes next to ease back into writing later.
              </li>
            </ul>
          </Section>
          
          <Section title="Establishing a Writing Routine">
            <p>
              A consistent writing routine is one of the most powerful tools for completing your novel. While inspiration is wonderful when it appears, a routine ensures you make progress even when inspiration is scarce.
            </p>
            
            <h3 className="text-xl font-semibold mt-6 mb-3">Elements of an Effective Routine</h3>
            
            <ul className="list-disc pl-6 space-y-2 my-4">
              <li>
                <strong>Consistency:</strong> Regular writing sessions, whether daily, several times a week, or on weekends.
              </li>
              <li>
                <strong>Designated time:</strong> A specific time for writing that becomes habitual.
              </li>
              <li>
                <strong>Dedicated space:</strong> A physical environment that signals "writing time" to your brain.
              </li>
              <li>
                <strong>Minimal distractions:</strong> Strategies to manage interruptions, both digital and physical.
              </li>
              <li>
                <strong>Clear expectations:</strong> Realistic goals for each session based on your circumstances.
              </li>
              <li>
                <strong>Start-up ritual:</strong> A consistent way to begin each writing session that eases you into the work.
              </li>
            </ul>
            
            <TipBox title="Finding Time to Write">
              <p>
                If you're struggling to find time for writing, try these approaches:
              </p>
              <ul className="list-disc pl-5 space-y-1 mt-2">
                <li>Write in short, frequent sessions (15-30 minutes) rather than waiting for long blocks of time</li>
                <li>Identify activities you can reduce to make room for writing (social media, television, etc.)</li>
                <li>Wake up 30 minutes earlier or stay up 30 minutes later</li>
                <li>Use lunch breaks or commute time (if you're not driving)</li>
                <li>Schedule writing sessions in your calendar as non-negotiable appointments</li>
                <li>Batch household tasks to create more efficient blocks of free time</li>
              </ul>
            </TipBox>
            
            <Exercise title="Design Your Ideal Writing Routine">
              <p>Create a writing routine that works with your life circumstances:</p>
              <ol className="list-decimal pl-6 space-y-1 mt-2">
                <li>When are you most mentally alert and creative? Morning, afternoon, evening?</li>
                <li>What realistic time blocks can you dedicate to writing each week?</li>
                <li>Where can you write with minimal distractions?</li>
                <li>What tools and resources do you need in your writing space?</li>
                <li>What simple ritual could signal to your brain that it's time to write?</li>
                <li>What reasonable word count or time goal would feel achievable but meaningful?</li>
              </ol>
              <p className="mt-3">
                Start with a routine you can consistently maintain, even if it's modest. You can always expand it as writing becomes more habitual.
              </p>
            </Exercise>
          </Section>
          
          <Section title="Managing Your Writing Project">
            <p>
              A novel is a complex, long-term project that benefits from thoughtful management. These strategies can help you organize your work and maintain progress over months of writing.
            </p>
            
            <h3 className="text-xl font-semibold mt-6 mb-3">Project Management for Writers</h3>
            
            <ul className="list-disc pl-6 space-y-2 my-4">
              <li>
                <strong>Document organization:</strong> Create a consistent system for storing and naming files, including different draft versions.
              </li>
              <li>
                <strong>Progress tracking:</strong> Monitor word count, completed scenes/chapters, or hours spent writing to visualize your progress.
              </li>
              <li>
                <strong>Project timeline:</strong> Establish realistic milestones and deadlines, even if they're just for yourself.
              </li>
              <li>
                <strong>Research management:</strong> Develop a system for organizing research materials and notes so they're easily accessible when needed.
              </li>
              <li>
                <strong>Idea capture:</strong> Keep a dedicated place (digital or physical) to record ideas that come at unexpected times.
              </li>
            </ul>
            
            <h3 className="text-xl font-semibold mt-6 mb-3">Tools for Writers</h3>
            
            <p>
              While you can write a novel with nothing more than a pen and paper or a basic word processor, specialized tools can support different aspects of the writing process:
            </p>
            
            <ul className="list-disc pl-6 space-y-2 my-4">
              <li>
                <strong>Writing software:</strong> Programs like Scrivener, Ulysses, or Dabble that help organize complex writing projects.
              </li>
              <li>
                <strong>Planning tools:</strong> Mind-mapping software, outlining apps, or physical index cards for plotting.
              </li>
              <li>
                <strong>Productivity aids:</strong> Timers, distraction-blocking apps, or ambient noise generators.
              </li>
              <li>
                <strong>Reference management:</strong> Tools for organizing research, character details, and world-building elements.
              </li>
              <li>
                <strong>Backup systems:</strong> Cloud storage, external drives, or email to ensure you never lose your work.
              </li>
            </ul>
            
            <p>
              The best tools are those that support your specific writing process without becoming a distraction themselves. Start with the simplest system that meets your needs, and add complexity only when necessary.
            </p>
            
            <p className="mt-4">
              In the next section, we'll explore self-reflection questions that can help you identify your strengths, challenges, and next steps as you develop your novel.
            </p>
          </Section>
        </div>
        
        <div className="lg:col-span-1">
          <Sidebar links={sidebarLinks} />
        </div>
      </div>
    </Layout>
  );
}
