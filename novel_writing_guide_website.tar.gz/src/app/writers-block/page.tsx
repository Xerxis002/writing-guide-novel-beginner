import Layout from '@/components/ui/layout';
import { Section, Quote, TipBox, Exercise, Sidebar } from '@/components/ui/content-blocks';

export default function Page() {
  const sidebarLinks = [
    { title: 'Understanding Writer\'s Block', href: '#understanding-writers-block' },
    { title: 'Prevention Strategies', href: '#prevention-strategies' },
    { title: 'Overcoming Creative Blocks', href: '#overcoming-creative-blocks' },
    { title: 'Maintaining Momentum', href: '#maintaining-momentum' },
    { title: 'When to Seek Help', href: '#when-to-seek-help' }
  ];

  return (
    <Layout>
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
        <div className="lg:col-span-3">
          <h1 className="text-4xl font-bold text-slate-900 mb-6">Overcoming Writer's Block</h1>
          
          <Section title="Understanding Writer's Block">
            <p>
              Writer's block—that frustrating inability to produce new work or make progress on a project—is a common experience for writers at all levels. Understanding what causes these creative blocks is the first step toward overcoming them.
            </p>
            
            <h3 className="text-xl font-semibold mt-6 mb-3">The Nature of Creative Blocks</h3>
            
            <p>
              Writer's block isn't a single condition but a symptom that can stem from various underlying causes:
            </p>
            
            <ul className="list-disc pl-6 space-y-2 my-4">
              <li>
                <strong>Fear and perfectionism:</strong> Anxiety about producing work that doesn't meet your standards.
              </li>
              <li>
                <strong>Overwhelm:</strong> Feeling intimidated by the scope or complexity of your project.
              </li>
              <li>
                <strong>Uncertainty:</strong> Not knowing where your story should go next or how to resolve plot problems.
              </li>
              <li>
                <strong>Burnout:</strong> Mental exhaustion from overwork or lack of creative replenishment.
              </li>
              <li>
                <strong>External pressures:</strong> Stress from deadlines, expectations, or life circumstances.
              </li>
              <li>
                <strong>Inner critic:</strong> Excessive self-judgment that inhibits creative flow.
              </li>
              <li>
                <strong>Lack of preparation:</strong> Insufficient planning or research for your current writing stage.
              </li>
              <li>
                <strong>Distractions:</strong> Environmental factors or internal preoccupations that prevent focus.
              </li>
            </ul>
            
            <p>
              Recognizing which factors are contributing to your block is essential for choosing the right strategies to overcome it.
            </p>
            
            <Quote 
              text="The scariest moment is always just before you start. After that, things can only get better."
              author="Stephen King"
            />
            
            <h3 className="text-xl font-semibold mt-6 mb-3">The Psychology of Creative Resistance</h3>
            
            <p>
              Writer's block often involves psychological resistance to the writing process. This resistance can manifest as:
            </p>
            
            <ul className="list-disc pl-6 space-y-2 my-4">
              <li>
                <strong>Procrastination:</strong> Finding other tasks to do instead of writing.
              </li>
              <li>
                <strong>Distraction-seeking:</strong> Constantly checking email, social media, or news.
              </li>
              <li>
                <strong>Perfectionism:</strong> Inability to write unless conditions feel perfect.
              </li>
              <li>
                <strong>Self-sabotage:</strong> Creating situations that make writing difficult or impossible.
              </li>
              <li>
                <strong>Impostor syndrome:</strong> Feeling unqualified or undeserving of writing success.
              </li>
              <li>
                <strong>Avoidance:</strong> Steering clear of difficult scenes or emotional content.
              </li>
            </ul>
            
            <p>
              Understanding that resistance is a normal part of the creative process—not a sign of failure or lack of talent—can help you develop a healthier relationship with these challenges.
            </p>
            
            <TipBox title="Identifying Your Specific Block">
              <p>
                When you're stuck, ask yourself these diagnostic questions:
              </p>
              <ul className="list-disc pl-5 space-y-1 mt-2">
                <li>Am I afraid of something specific about this project?</li>
                <li>Do I know what happens next in my story?</li>
                <li>Am I physically or mentally exhausted?</li>
                <li>Am I trying to write something that doesn't excite me?</li>
                <li>Is my environment conducive to focus?</li>
                <li>Have I been nurturing my creativity lately?</li>
                <li>Am I putting too much pressure on this particular piece of writing?</li>
                <li>Do I have the information or skills I need for this section?</li>
              </ul>
              <p className="mt-2">
                Your answers will point toward the specific strategies most likely to help you move forward.
              </p>
            </TipBox>
          </Section>
          
          <Section title="Prevention Strategies">
            <p>
              The best way to deal with writer's block is to prevent it from taking hold in the first place. These practices can help you maintain creative flow and minimize blocks before they occur.
            </p>
            
            <h3 className="text-xl font-semibold mt-6 mb-3">Establishing a Writing Routine</h3>
            
            <p>
              A consistent writing practice builds creative momentum and trains your mind to engage with writing regularly:
            </p>
            
            <ul className="list-disc pl-6 space-y-2 my-4">
              <li>
                <strong>Schedule regular writing sessions:</strong> Write at the same times each day or week to establish a habit.
              </li>
              <li>
                <strong>Create start-up rituals:</strong> Develop simple routines that signal to your brain it's time to write.
              </li>
              <li>
                <strong>Set realistic goals:</strong> Aim for achievable targets like time spent writing or word counts.
              </li>
              <li>
                <strong>Track your progress:</strong> Record your writing activity to build motivation and accountability.
              </li>
              <li>
                <strong>Honor your process:</strong> Work with your natural rhythms and preferences when possible.
              </li>
              <li>
                <strong>Separate creation from editing:</strong> Don't try to perfect your work while generating it.
              </li>
            </ul>
            
            <h3 className="text-xl font-semibold mt-6 mb-3">Nurturing Your Creativity</h3>
            
            <p>
              Creativity requires regular nourishment and replenishment:
            </p>
            
            <ul className="list-disc pl-6 space-y-2 my-4">
              <li>
                <strong>Read widely:</strong> Expose yourself to diverse writing styles and genres.
              </li>
              <li>
                <strong>Collect inspiration:</strong> Keep a notebook or digital file of ideas, images, and observations.
              </li>
              <li>
                <strong>Engage with other art forms:</strong> Music, visual art, film, and theater can spark new ideas.
              </li>
              <li>
                <strong>Experience new things:</strong> Travel, try new activities, or explore unfamiliar environments.
              </li>
              <li>
                <strong>Connect with other writers:</strong> Share experiences and support with a writing community.
              </li>
              <li>
                <strong>Practice mindfulness:</strong> Develop awareness of your thoughts, feelings, and surroundings.
              </li>
              <li>
                <strong>Allow for fallow periods:</strong> Recognize that creativity has natural cycles of productivity and rest.
              </li>
            </ul>
            
            <h3 className="text-xl font-semibold mt-6 mb-3">Planning and Preparation</h3>
            
            <p>
              Adequate preparation provides a foundation that makes writing flow more easily:
            </p>
            
            <ul className="list-disc pl-6 space-y-2 my-4">
              <li>
                <strong>Outline your project:</strong> Create a roadmap that guides your writing, even if it's just a rough sketch.
              </li>
              <li>
                <strong>Research in advance:</strong> Gather necessary information before you need it in your writing.
              </li>
              <li>
                <strong>Develop character profiles:</strong> Know your characters well enough that their actions and reactions feel natural.
              </li>
              <li>
                <strong>Create scene cards:</strong> Prepare brief descriptions of upcoming scenes to give yourself clear direction.
              </li>
              <li>
                <strong>End writing sessions mid-flow:</strong> Stop writing when you know what comes next, making it easier to resume.
              </li>
              <li>
                <strong>Leave notes for yourself:</strong> Before ending a session, jot down ideas for where to start next time.
              </li>
            </ul>
            
            <Exercise title="Block Prevention Plan">
              <p>Create a personalized writer's block prevention plan:</p>
              <ol className="list-decimal pl-6 space-y-1 mt-2">
                <li>Identify your optimal writing times based on your energy levels and schedule</li>
                <li>Design a 5-10 minute pre-writing ritual that helps you transition into creative mode</li>
                <li>List 3-5 activities that reliably inspire or energize your creativity</li>
                <li>Determine your ideal writing environment (location, sound level, temperature, etc.)</li>
                <li>Set up a system for capturing ideas when you're not actively writing</li>
                <li>Create a realistic writing schedule that you can maintain consistently</li>
                <li>Establish how you'll track your progress and celebrate small victories</li>
              </ol>
              <p className="mt-3">
                Implement this plan for at least two weeks, then assess what's working and what needs adjustment.
              </p>
            </Exercise>
          </Section>
          
          <Section title="Overcoming Creative Blocks">
            <p>
              Even with good prevention practices, most writers occasionally encounter blocks. These strategies can help you break through when you're stuck.
            </p>
            
            <h3 className="text-xl font-semibold mt-6 mb-3">Practical Techniques for Getting Unstuck</h3>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 my-6">
              <div className="bg-blue-50 p-4 rounded">
                <h4 className="font-semibold text-blue-800 mb-2">Freewriting</h4>
                <p>Write continuously for a set period (10-15 minutes) without stopping, editing, or judging. Write anything that comes to mind, even if it seems unrelated to your project.</p>
                <p className="mt-2 text-sm"><strong>Best for:</strong> Silencing the inner critic, generating raw material, warming up</p>
              </div>
              
              <div className="bg-green-50 p-4 rounded">
                <h4 className="font-semibold text-green-800 mb-2">Change of Perspective</h4>
                <p>Rewrite a scene from a different character's viewpoint, or switch from first person to third person (or vice versa).</p>
                <p className="mt-2 text-sm"><strong>Best for:</strong> Finding new angles on stuck scenes, deepening character understanding</p>
              </div>
              
              <div className="bg-purple-50 p-4 rounded">
                <h4 className="font-semibold text-purple-800 mb-2">Skip Ahead</h4>
                <p>Leave the troublesome section temporarily and write a scene you're excited about that comes later in the story.</p>
                <p className="mt-2 text-sm"><strong>Best for:</strong> Maintaining momentum, generating enthusiasm for the project</p>
              </div>
              
              <div className="bg-amber-50 p-4 rounded">
                <h4 className="font-semibold text-amber-800 mb-2">Dialogue-Only Scene</h4>
                <p>Write only the dialogue for a scene, without any description or tags. Focus on the conversation's flow and content.</p>
                <p className="mt-2 text-sm"><strong>Best for:</strong> Character development, finding the heart of a scene</p>
              </div>
              
              <div className="bg-rose-50 p-4 rounded">
                <h4 className="font-semibold text-rose-800 mb-2">Prompt Response</h4>
                <p>Use a writing prompt unrelated to your project to get words flowing, then transition to your manuscript.</p>
                <p className="mt-2 text-sm"><strong>Best for:</strong> Warming up, bypassing psychological resistance</p>
              </div>
              
              <div className="bg-cyan-50 p-4 rounded">
                <h4 className="font-semibold text-cyan-800 mb-2">Change of Environment</h4>
                <p>Move to a different location to write—a café, library, park, or even another room in your home.</p>
                <p className="mt-2 text-sm"><strong>Best for:</strong> Breaking patterns, finding fresh inspiration</p>
              </div>
            </div>
            
            <h3 className="text-xl font-semibold mt-6 mb-3">Addressing Specific Types of Blocks</h3>
            
            <h4 className="text-lg font-medium mt-4 mb-2">For Plot Problems:</h4>
            
            <ul className="list-disc pl-6 space-y-1 my-2">
              <li>Ask "what if" questions to generate alternative plot directions</li>
              <li>Work backward from your desired ending to find the path there</li>
              <li>Introduce a new complication or obstacle for your character</li>
              <li>Revisit your character's core motivation and let it guide the plot</li>
              <li>Map out cause-and-effect relationships between events</li>
            </ul>
            
            <h4 className="text-lg font-medium mt-4 mb-2">For Character Issues:</h4>
            
            <ul className="list-disc pl-6 space-y-1 my-2">
              <li>Write a character interview or monologue to explore their thoughts</li>
              <li>Create a detailed backstory, even if it won't appear in the novel</li>
              <li>Write a scene showing the character in an extreme situation</li>
              <li>Identify what the character wants most and what they fear most</li>
              <li>Develop relationships between characters through dialogue exercises</li>
            </ul>
            
            <h4 className="text-lg font-medium mt-4 mb-2">For Perfectionism and Fear:</h4>
            
            <ul className="list-disc pl-6 space-y-1 my-2">
              <li>Set a timer and write as poorly as possible for 10 minutes</li>
              <li>Write a letter to your inner critic acknowledging concerns but setting boundaries</li>
              <li>Create a "shitty first draft" with the explicit intention of revising later</li>
              <li>Share your struggles with supportive fellow writers</li>
              <li>Remind yourself that all writers produce imperfect first drafts</li>
            </ul>
            
            <h4 className="text-lg font-medium mt-4 mb-2">For Burnout and Exhaustion:</h4>
            
            <ul className="list-disc pl-6 space-y-1 my-2">
              <li>Take a deliberate, guilt-free break from writing</li>
              <li>Engage in activities that replenish your creative energy</li>
              <li>Read books that remind you why you love writing</li>
              <li>Reduce your daily word count goal temporarily</li>
              <li>Focus on self-care: sleep, exercise, nutrition, and relaxation</li>
            </ul>
            
            <Quote 
              text="The way to get started is to quit talking and begin doing."
              author="Walt Disney"
            />
            
            <h3 className="text-xl font-semibold mt-6 mb-3">Reframing Your Relationship with Blocks</h3>
            
            <p>
              How you think about creative blocks significantly impacts your ability to overcome them:
            </p>
            
            <ul className="list-disc pl-6 space-y-2 my-4">
              <li>
                <strong>See blocks as information:</strong> They often signal something important about your process or project.
              </li>
              <li>
                <strong>Normalize the experience:</strong> All writers face blocks; they don't reflect your worth or talent.
              </li>
              <li>
                <strong>Focus on process, not product:</strong> Shift attention from results to the act of writing itself.
              </li>
              <li>
                <strong>Embrace imperfection:</strong> Accept that creating something imperfect is better than creating nothing.
              </li>
              <li>
                <strong>Practice self-compassion:</strong> Treat yourself with the kindness you would offer a friend facing similar challenges.
              </li>
              <li>
                <strong>Redefine success:</strong> Count showing up to write as a victory, regardless of output.
              </li>
            </ul>
            
            <TipBox title="Permission Slip Exercise">
              <p>
                Write yourself a formal "permission slip" that addresses your specific creative blocks. For example:
              </p>
              <div className="bg-white p-3 border border-gray-300 rounded mt-2 italic">
                <p>I hereby give myself permission to:</p>
                <ul className="list-disc pl-5 space-y-1 mt-1">
                  <li>Write a terrible first draft without judgment</li>
                  <li>Take breaks when I need them without guilt</li>
                  <li>Write out of sequence when I'm stuck</li>
                  <li>Experiment and play with my story</li>
                  <li>Change my outline if the story wants to go in a different direction</li>
                  <li>Write slowly if that's what my process requires</li>
                </ul>
                <p className="mt-2">Signed, [Your Name]</p>
              </div>
              <p className="mt-2">
                Keep this permission slip visible in your writing space as a reminder when blocks arise.
              </p>
            </TipBox>
          </Section>
          
          <Section title="Maintaining Momentum">
            <p>
              Once you've overcome a block, maintaining forward momentum becomes the priority. These strategies help you build and sustain a consistent writing practice.
            </p>
            
            <h3 className="text-xl font-semibold mt-6 mb-3">Building a Sustainable Writing Habit</h3>
            
            <p>
              Consistent habits are more effective than sporadic bursts of productivity:
            </p>
            
            <ul className="list-disc pl-6 space-y-2 my-4">
              <li>
                <strong>Start small:</strong> Begin with manageable writing sessions (even just 15-30 minutes) that you can consistently maintain.
              </li>
              <li>
                <strong>Increase gradually:</strong> Slowly extend your writing time as the habit becomes established.
              </li>
              <li>
                <strong>Track your progress:</strong> Use a calendar, app, or journal to record your writing activity.
              </li>
              <li>
                <strong>Create accountability:</strong> Share your goals with others or join a writing group.
              </li>
              <li>
                <strong>Identify triggers:</strong> Notice what situations or thoughts typically precede resistance.
              </li>
              <li>
                <strong>Develop cues:</strong> Establish environmental or behavioral cues that signal it's time to write.
              </li>
              <li>
                <strong>Reward consistency:</strong> Celebrate showing up for your writing practice, regardless of output.
              </li>
            </ul>
            
            <h3 className="text-xl font-semibold mt-6 mb-3">Managing Energy and Attention</h3>
            
            <p>
              Writing requires mental energy and focused attention, both finite resources:
            </p>
            
            <ul className="list-disc pl-6 space-y-2 my-4">
              <li>
                <strong>Identify your peak creative times:</strong> Schedule important writing sessions during your natural high-energy periods.
              </li>
              <li>
                <strong>Minimize distractions:</strong> Use website blockers, silence notifications, or create a dedicated writing environment.
              </li>
              <li>
                <strong>Practice focused work:</strong> Train your attention through timed writing sessions with no interruptions.
              </li>
              <li>
                <strong>Take strategic breaks:</strong> Use techniques like the Pomodoro method (25 minutes of work followed by a 5-minute break).
              </li>
              <li>
                <strong>Manage decision fatigue:</strong> Plan what you'll work on before you begin writing to preserve mental energy.
              </li>
              <li>
                <strong>Protect your creative resources:</strong> Set boundaries around activities that drain your energy without replenishing it.
              </li>
              <li>
                <strong>Practice mindfulness:</strong> Regular meditation or mindfulness exercises can improve focus and attention.
              </li>
            </ul>
            
            <h3 className="text-xl font-semibold mt-6 mb-3">Creating Momentum-Building Tools</h3>
            
            <p>
              Develop personalized tools that help you maintain progress:
            </p>
            
            <ul className="list-disc pl-6 space-y-2 my-4">
              <li>
                <strong>Progress tracker:</strong> Visualize your advancement through your novel with a chart or graph.
              </li>
              <li>
                <strong>Scene list:</strong> Maintain a list of scenes to write, allowing you to work on what most inspires you each day.
              </li>
              <li>
                <strong>Writing prompts collection:</strong> Gather prompts specific to your project for days when you need a jumpstart.
              </li>
              <li>
                <strong>Inspiration file:</strong> Collect images, quotes, music, or other materials that reconnect you with your story's essence.
              </li>
              <li>
                <strong>Accountability system:</strong> Create check-ins with writing partners or use public commitment to maintain consistency.
              </li>
              <li>
                <strong>Transition rituals:</strong> Develop brief activities that help you shift from daily life into your creative mindset.
              </li>
            </ul>
            
            <Exercise title="Momentum Maintenance Plan">
              <p>Create a personalized plan to maintain writing momentum:</p>
              <ol className="list-decimal pl-6 space-y-1 mt-2">
                <li>Identify your minimum viable writing session (the shortest time that still feels productive)</li>
                <li>Schedule at least three such sessions in your calendar for the coming week</li>
                <li>List three specific actions you'll take when you feel resistance arising</li>
                <li>Create a simple tracking system to record your writing consistency</li>
                <li>Identify a writing buddy or group for regular check-ins</li>
                <li>Plan a meaningful reward for meeting your consistency goals</li>
                <li>Write a brief statement about why this project matters to you to revisit when motivation wanes</li>
              </ol>
              <p className="mt-3">
                Review and adjust this plan monthly based on what's working and what needs modification.
              </p>
            </Exercise>
          </Section>
          
          <Section title="When to Seek Help">
            <p>
              Sometimes writer's block persists despite your best efforts. Knowing when and how to seek outside help is an important part of maintaining your creative health.
            </p>
            
            <h3 className="text-xl font-semibold mt-6 mb-3">Recognizing Persistent Blocks</h3>
            
            <p>
              Consider seeking additional support if your block:
            </p>
            
            <ul className="list-disc pl-6 space-y-2 my-4">
              <li>
                <strong>Persists for an extended period:</strong> Weeks or months without progress despite consistent effort.
              </li>
              <li>
                <strong>Causes significant distress:</strong> Creates anxiety, depression, or impacts your self-worth.
              </li>
              <li>
                <strong>Affects other areas of life:</strong> Spills over into work, relationships, or daily functioning.
              </li>
              <li>
                <strong>Resists multiple strategies:</strong> Continues despite trying various techniques and approaches.
              </li>
              <li>
                <strong>Feels different from normal resistance:</strong> Seems more intense or qualitatively different from typical creative challenges.
              </li>
              <li>
                <strong>Involves recurring negative thought patterns:</strong> Includes persistent self-criticism or catastrophic thinking.
              </li>
            </ul>
            
            <h3 className="text-xl font-semibold mt-6 mb-3">Types of Support</h3>
            
            <p>
              Different kinds of assistance can address different aspects of creative blocks:
            </p>
            
            <ul className="list-disc pl-6 space-y-2 my-4">
              <li>
                <strong>Writing communities:</strong> Groups that provide encouragement, accountability, and shared experience.
              </li>
              <li>
                <strong>Writing coaches:</strong> Professionals who help with specific writing challenges and provide structured guidance.
              </li>
              <li>
                <strong>Developmental editors:</strong> Experts who can identify and help resolve structural or craft issues in your manuscript.
              </li>
              <li>
                <strong>Creativity workshops:</strong> Structured programs designed to unblock creative flow and develop new skills.
              </li>
              <li>
                <strong>Writing courses:</strong> Classes that address specific aspects of craft that may be causing difficulty.
              </li>
              <li>
                <strong>Therapy or counseling:</strong> Professional support for underlying psychological issues that may be affecting creativity.
              </li>
              <li>
                <strong>Creative arts therapies:</strong> Approaches that use various art forms to address creative and emotional blocks.
              </li>
            </ul>
            
            <h3 className="text-xl font-semibold mt-6 mb-3">When Blocks Signal Deeper Issues</h3>
            
            <p>
              Sometimes persistent creative blocks reflect underlying concerns:
            </p>
            
            <ul className="list-disc pl-6 space-y-2 my-4">
              <li>
                <strong>Project mismatch:</strong> The current project may not align with your authentic interests or values.
              </li>
              <li>
                <strong>Skill development needs:</strong> You may need to develop specific writing skills before proceeding.
              </li>
              <li>
                <strong>Life transitions:</strong> Major life changes can temporarily affect creative capacity.
              </li>
              <li>
                <strong>Mental health concerns:</strong> Conditions like depression, anxiety, or ADHD can impact creative function.
              </li>
              <li>
                <strong>Burnout:</strong> Extended overwork without adequate rest and replenishment.
              </li>
              <li>
                <strong>Unresolved trauma:</strong> Past experiences that emerge when engaging with certain content.
              </li>
              <li>
                <strong>Creative evolution:</strong> Your artistic direction may be changing in ways that create temporary disruption.
              </li>
            </ul>
            
            <TipBox title="Self-Assessment Questions">
              <p>
                If you're experiencing a persistent block, consider these questions:
              </p>
              <ul className="list-disc pl-5 space-y-1 mt-2">
                <li>Does this block feel different from normal resistance or temporary stuck points?</li>
                <li>Has my relationship with writing changed in a fundamental way?</li>
                <li>Are there themes or content in my current project that feel emotionally charged?</li>
                <li>Have there been significant changes in other areas of my life?</li>
                <li>Am I experiencing symptoms of depression, anxiety, or other mental health concerns?</li>
                <li>Do I feel a sense of dread or avoidance when approaching my writing?</li>
                <li>Has my creative vision for this project become unclear or conflicted?</li>
              </ul>
              <p className="mt-2">
                Your answers may indicate whether professional support would be beneficial.
              </p>
            </TipBox>
            
            <p className="mt-4">
              Remember that seeking help is a sign of commitment to your craft, not weakness. Many successful writers work with coaches, therapists, editors, and communities to support their creative practice.
            </p>
            
            <p className="mt-4">
              In the next section, we'll explore strategies for building confidence and maintaining commitment to your novel-writing journey.
            </p>
          </Section>
        </div>
        
        <div className="lg:col-span-1">
          <Sidebar links={sidebarLinks} />
        </div>
      </div>
    </Layout>
  );
}
