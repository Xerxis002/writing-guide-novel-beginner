import Layout from '@/components/ui/layout';
import { Section, Quote, TipBox, Exercise, Sidebar } from '@/components/ui/content-blocks';

export default function Page() {
  const sidebarLinks = [
    { title: 'Understanding Your Writing Journey', href: '#understanding-your-writing-journey' },
    { title: 'Questions About Your Story', href: '#questions-about-your-story' },
    { title: 'Questions About Your Process', href: '#questions-about-your-process' },
    { title: 'Questions About Your Growth', href: '#questions-about-your-growth' },
    { title: 'Using Self-Reflection Effectively', href: '#using-self-reflection-effectively' }
  ];

  return (
    <Layout>
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
        <div className="lg:col-span-3">
          <h1 className="text-4xl font-bold text-slate-900 mb-6">Self-Reflection Questions</h1>
          
          <Section title="Understanding Your Writing Journey">
            <p>
              Self-reflection is a powerful tool for novel writers. By asking yourself thoughtful questions throughout your writing journey, you gain valuable insights that can help you overcome obstacles, make informed decisions, and deepen your connection to your work.
            </p>
            
            <p>
              This section provides a collection of questions designed to help you reflect on different aspects of your novel-writing experience. These questions serve multiple purposes:
            </p>
            
            <ul className="list-disc pl-6 space-y-2 my-4">
              <li>
                <strong>Clarify your vision</strong> for your novel and what you hope to accomplish
              </li>
              <li>
                <strong>Identify strengths and challenges</strong> in your story and writing process
              </li>
              <li>
                <strong>Make conscious decisions</strong> about your approach rather than defaulting to habits
              </li>
              <li>
                <strong>Track your growth</strong> as a writer over time
              </li>
              <li>
                <strong>Reconnect with your purpose</strong> when motivation wanes
              </li>
            </ul>
            
            <p>
              You don't need to answer all these questions at once. Instead, select those that seem most relevant to your current situation or challenges. Return to this section whenever you need guidance or feel stuck in your writing process.
            </p>
            
            <Quote 
              text="The unexamined life is not worth living. The unexamined novel is not worth writing."
              author="Adapted from Socrates"
            />
          </Section>
          
          <Section title="Questions About Your Story">
            <p>
              These questions help you explore and strengthen the fundamental elements of your novel.
            </p>
            
            <h3 className="text-xl font-semibold mt-6 mb-3">Core Concept</h3>
            
            <ul className="list-disc pl-6 space-y-2 my-4">
              <li>What question, idea, or situation initially sparked this story?</li>
              <li>If you had to describe your novel in one sentence, what would it be?</li>
              <li>What makes this story uniquely yours to tell?</li>
              <li>What do you want readers to feel or think about after reading your novel?</li>
              <li>What excites you most about this story? What scares you?</li>
            </ul>
            
            <h3 className="text-xl font-semibold mt-6 mb-3">Characters</h3>
            
            <ul className="list-disc pl-6 space-y-2 my-4">
              <li>What does your protagonist want most? What do they need (which may differ from what they want)?</li>
              <li>What prevents your protagonist from achieving their goals?</li>
              <li>How does your protagonist change throughout the story?</li>
              <li>What are your antagonist's motivations? Do they believe they're doing the right thing?</li>
              <li>Which character do you find most challenging to write? Why?</li>
              <li>Do your characters make choices that drive the plot, or do they primarily react to events?</li>
              <li>How do your characters' backgrounds influence their perspectives and choices?</li>
            </ul>
            
            <h3 className="text-xl font-semibold mt-6 mb-3">Plot and Structure</h3>
            
            <ul className="list-disc pl-6 space-y-2 my-4">
              <li>What is the central conflict of your story?</li>
              <li>Does your opening hook the reader? How?</li>
              <li>What are the major turning points in your story?</li>
              <li>Are there sections where the pacing feels too slow or too rushed?</li>
              <li>Does each scene advance the plot, develop character, or preferably both?</li>
              <li>How does the ending resolve the central conflict and character arcs?</li>
              <li>If you removed a particular scene, would the story still make sense? Would something important be lost?</li>
            </ul>
            
            <h3 className="text-xl font-semibold mt-6 mb-3">Setting and World</h3>
            
            <ul className="list-disc pl-6 space-y-2 my-4">
              <li>How does your setting influence the story and characters?</li>
              <li>What sensory details make your world come alive?</li>
              <li>What rules (social, physical, magical) govern your story world?</li>
              <li>How do characters interact with and respond to their environment?</li>
              <li>What research might deepen your understanding of the world you're creating?</li>
            </ul>
            
            <h3 className="text-xl font-semibold mt-6 mb-3">Theme and Meaning</h3>
            
            <ul className="list-disc pl-6 space-y-2 my-4">
              <li>What themes or ideas are you exploring in your novel?</li>
              <li>How do your characters and plot developments reflect these themes?</li>
              <li>What questions does your story ask (even if it doesn't answer them)?</li>
              <li>What personal values or beliefs influence your storytelling?</li>
              <li>How might different readers interpret your story's meaning?</li>
            </ul>
            
            <Exercise title="Story Element Deep Dive">
              <p>Choose one element of your story that feels underdeveloped or challenging. Spend 15-20 minutes free-writing responses to the relevant questions above. Don't censor yourself or worry about implementation yet—just explore possibilities.</p>
              <p className="mt-2">After your free-writing session, highlight 2-3 insights that feel most significant or energizing. Consider how you might incorporate these insights into your novel.</p>
            </Exercise>
          </Section>
          
          <Section title="Questions About Your Process">
            <p>
              These questions help you understand and optimize your writing approach.
            </p>
            
            <h3 className="text-xl font-semibold mt-6 mb-3">Writing Habits</h3>
            
            <ul className="list-disc pl-6 space-y-2 my-4">
              <li>When do you feel most creative and focused?</li>
              <li>What conditions help you write most effectively?</li>
              <li>What typically distracts or derails your writing sessions?</li>
              <li>How do you balance planning and spontaneity in your writing?</li>
              <li>What writing schedule is realistic given your current life circumstances?</li>
              <li>How do you track your progress? Is this method motivating?</li>
            </ul>
            
            <h3 className="text-xl font-semibold mt-6 mb-3">Challenges and Blocks</h3>
            
            <ul className="list-disc pl-6 space-y-2 my-4">
              <li>What aspects of writing do you find most challenging?</li>
              <li>When you feel stuck, what strategies have helped you move forward?</li>
              <li>What fears or doubts arise during your writing process?</li>
              <li>How do you respond to these fears? Do your responses help or hinder your progress?</li>
              <li>What external pressures affect your writing experience?</li>
              <li>What stories or beliefs about writing might be limiting you?</li>
            </ul>
            
            <h3 className="text-xl font-semibold mt-6 mb-3">Support and Resources</h3>
            
            <ul className="list-disc pl-6 space-y-2 my-4">
              <li>What resources have been most helpful in developing your writing skills?</li>
              <li>Who supports your writing journey? How?</li>
              <li>What additional support or resources might help you progress?</li>
              <li>How do you respond to feedback? What type of feedback is most useful to you?</li>
              <li>What communities or connections would enhance your writing life?</li>
            </ul>
            
            <TipBox title="Process Journal">
              <p>
                Consider keeping a process journal separate from your novel manuscript. Use this journal to:
              </p>
              <ul className="list-disc pl-5 space-y-1 mt-2">
                <li>Record your responses to these self-reflection questions</li>
                <li>Document what works and what doesn't in your writing process</li>
                <li>Track patterns in your productivity and creative energy</li>
                <li>Note solutions to recurring challenges</li>
                <li>Celebrate progress and milestones</li>
              </ul>
              <p className="mt-2">
                Reviewing this journal periodically can reveal valuable insights about your evolving writing process.
              </p>
            </TipBox>
          </Section>
          
          <Section title="Questions About Your Growth">
            <p>
              These questions help you recognize your development as a writer and set meaningful goals.
            </p>
            
            <h3 className="text-xl font-semibold mt-6 mb-3">Skills and Learning</h3>
            
            <ul className="list-disc pl-6 space-y-2 my-4">
              <li>What writing skills have improved since you began this project?</li>
              <li>What aspects of writing would you like to strengthen?</li>
              <li>What have you learned about yourself through this writing process?</li>
              <li>How has your understanding of storytelling evolved?</li>
              <li>What writing techniques are you experimenting with in this project?</li>
            </ul>
            
            <h3 className="text-xl font-semibold mt-6 mb-3">Motivation and Purpose</h3>
            
            <ul className="list-disc pl-6 space-y-2 my-4">
              <li>Why is writing this particular novel important to you?</li>
              <li>What keeps you coming back to this project despite challenges?</li>
              <li>How does this novel connect to your larger goals or values?</li>
              <li>What would feel like success with this project?</li>
              <li>How has your relationship with this story changed since you began?</li>
            </ul>
            
            <h3 className="text-xl font-semibold mt-6 mb-3">Future Direction</h3>
            
            <ul className="list-disc pl-6 space-y-2 my-4">
              <li>What are your next steps with this project?</li>
              <li>What excites you about future writing projects?</li>
              <li>What writing skills do you want to develop in the coming year?</li>
              <li>How might you challenge yourself creatively in your next project?</li>
              <li>What kind of writing career or practice do you envision for yourself?</li>
            </ul>
            
            <Exercise title="Growth Reflection">
              <p>Take a moment to acknowledge your growth as a writer:</p>
              <ol className="list-decimal pl-6 space-y-1 mt-2">
                <li>List three writing skills or qualities you've developed or strengthened</li>
                <li>Describe a writing challenge you've overcome and what you learned from it</li>
                <li>Identify one aspect of writing where you'd like to grow next</li>
                <li>Note one specific action you can take to develop in this area</li>
              </ol>
              <p className="mt-3">
                Consider revisiting this exercise every few months to track your progress and set new growth goals.
              </p>
            </Exercise>
          </Section>
          
          <Section title="Using Self-Reflection Effectively">
            <p>
              Self-reflection is most valuable when it leads to insight and action. Here are strategies for making the most of these questions:
            </p>
            
            <h3 className="text-xl font-semibold mt-6 mb-3">When to Reflect</h3>
            
            <ul className="list-disc pl-6 space-y-2 my-4">
              <li>
                <strong>At project milestones:</strong> Beginning a new novel, completing a draft, starting revision
              </li>
              <li>
                <strong>When facing challenges:</strong> Feeling stuck, losing motivation, encountering plot problems
              </li>
              <li>
                <strong>During scheduled reviews:</strong> Weekly or monthly check-ins on your progress and process
              </li>
              <li>
                <strong>After receiving feedback:</strong> Processing reactions and deciding what changes to make
              </li>
              <li>
                <strong>Before making significant decisions:</strong> Changing direction, starting or abandoning projects
              </li>
            </ul>
            
            <h3 className="text-xl font-semibold mt-6 mb-3">Reflection Methods</h3>
            
            <p>
              Different approaches to reflection work better for different people:
            </p>
            
            <ul className="list-disc pl-6 space-y-2 my-4">
              <li>
                <strong>Written reflection:</strong> Journaling responses to selected questions
              </li>
              <li>
                <strong>Verbal processing:</strong> Discussing questions with a writing partner or group
              </li>
              <li>
                <strong>Visual mapping:</strong> Creating mind maps or diagrams to explore connections
              </li>
              <li>
                <strong>Meditative reflection:</strong> Quietly contemplating questions during a walk or meditation
              </li>
              <li>
                <strong>Recorded reflection:</strong> Audio recording your thoughts for later review
              </li>
            </ul>
            
            <h3 className="text-xl font-semibold mt-6 mb-3">From Reflection to Action</h3>
            
            <p>
              To ensure reflection leads to meaningful progress:
            </p>
            
            <ol className="list-decimal pl-6 space-y-2 my-4">
              <li>
                <strong>Identify key insights</strong> from your reflection
              </li>
              <li>
                <strong>Determine specific actions</strong> based on these insights
              </li>
              <li>
                <strong>Implement small changes</strong> before attempting major revisions
              </li>
              <li>
                <strong>Evaluate the results</strong> of these changes
              </li>
              <li>
                <strong>Adjust your approach</strong> based on what you learn
              </li>
            </ol>
            
            <Quote 
              text="We do not learn from experience... we learn from reflecting on experience."
              author="John Dewey"
            />
            
            <p className="mt-4">
              Remember that self-reflection is not about judgment but about growth. Approach these questions with curiosity rather than criticism, and use your insights to continually refine both your story and your writing process.
            </p>
            
            <p>
              In the next section, we'll explore character development—creating compelling, complex characters that drive your story and engage your readers.
            </p>
          </Section>
        </div>
        
        <div className="lg:col-span-1">
          <Sidebar links={sidebarLinks} />
        </div>
      </div>
    </Layout>
  );
}
