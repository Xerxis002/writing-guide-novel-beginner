import Layout from '@/components/ui/layout';
import { Section, Quote, TipBox, Exercise, Sidebar } from '@/components/ui/content-blocks';

export default function Page() {
  const sidebarLinks = [
    { title: 'Story Structure Fundamentals', href: '#story-structure-fundamentals' },
    { title: 'Plot Development', href: '#plot-development' },
    { title: 'Story Arcs and Narrative Shapes', href: '#story-arcs-and-narrative-shapes' },
    { title: 'Scene Construction', href: '#scene-construction' },
    { title: 'Pacing and Rhythm', href: '#pacing-and-rhythm' }
  ];

  return (
    <Layout>
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
        <div className="lg:col-span-3">
          <h1 className="text-4xl font-bold text-slate-900 mb-6">Plotting and Structure</h1>
          
          <Section title="Story Structure Fundamentals">
            <p>
              Story structure provides the architectural framework for your novel. A well-structured story guides readers through a satisfying emotional and intellectual journey, creating a sense of purpose and momentum that keeps them engaged from beginning to end.
            </p>
            
            <p>
              While there are many approaches to structure, all effective stories share certain fundamental elements that create a cohesive and compelling narrative experience.
            </p>
            
            <h3 className="text-xl font-semibold mt-6 mb-3">The Purpose of Structure</h3>
            
            <p>
              Story structure serves several essential functions:
            </p>
            
            <ul className="list-disc pl-6 space-y-2 my-4">
              <li>
                <strong>Creates narrative momentum:</strong> Structure helps maintain forward movement and reader interest.
              </li>
              <li>
                <strong>Provides emotional rhythm:</strong> Well-structured stories deliver a satisfying pattern of tension and release.
              </li>
              <li>
                <strong>Organizes complex information:</strong> Structure helps readers follow and make sense of your narrative.
              </li>
              <li>
                <strong>Supports theme development:</strong> Structure can reinforce and develop your novel's central ideas.
              </li>
              <li>
                <strong>Guides character development:</strong> Structure creates a framework for meaningful character growth.
              </li>
            </ul>
            
            <Quote 
              text="Structure is not a formula to follow; it's a map that helps both the writer and the reader navigate the emotional journey of the story."
              author="Robert McKee"
            />
            
            <h3 className="text-xl font-semibold mt-6 mb-3">Core Structural Elements</h3>
            
            <p>
              Most effective stories contain these fundamental elements:
            </p>
            
            <ul className="list-disc pl-6 space-y-2 my-4">
              <li>
                <strong>Hook:</strong> An engaging opening that captures reader interest and establishes tone.
              </li>
              <li>
                <strong>Inciting incident:</strong> The event that disrupts the protagonist's normal life and sets the story in motion.
              </li>
              <li>
                <strong>Rising action:</strong> Escalating complications and challenges that test the protagonist.
              </li>
              <li>
                <strong>Turning points:</strong> Significant shifts that change the direction of the story.
              </li>
              <li>
                <strong>Midpoint:</strong> A pivotal moment that often represents a major shift in the protagonist's understanding or approach.
              </li>
              <li>
                <strong>Crisis/climax:</strong> The highest point of tension where the central conflict comes to a head.
              </li>
              <li>
                <strong>Resolution:</strong> The aftermath that shows the consequences of the climax and provides closure.
              </li>
            </ul>
            
            <p>
              These elements can be arranged in various ways depending on the structural approach you choose, but most successful novels incorporate them in some form.
            </p>
            
            <h3 className="text-xl font-semibold mt-6 mb-3">Approaches to Structure</h3>
            
            <p>
              There are many structural frameworks you can use to organize your novel:
            </p>
            
            <ul className="list-disc pl-6 space-y-2 my-4">
              <li>
                <strong>Three-act structure:</strong> The classic beginning, middle, and end approach used in many novels and films.
              </li>
              <li>
                <strong>Hero's journey:</strong> A mythic structure involving a call to adventure, trials, and return with new knowledge.
              </li>
              <li>
                <strong>Five-act structure:</strong> A more complex framework with exposition, rising action, climax, falling action, and resolution.
              </li>
              <li>
                <strong>Seven-point structure:</strong> A detailed approach with hook, plot turn 1, pinch point 1, midpoint, pinch point 2, plot turn 2, and resolution.
              </li>
              <li>
                <strong>Episodic structure:</strong> A series of connected incidents or episodes rather than a single arc.
              </li>
              <li>
                <strong>Nonlinear structure:</strong> A narrative that intentionally disrupts chronological order for artistic effect.
              </li>
            </ul>
            
            <p>
              The best structure for your novel depends on your story's specific needs, your genre conventions, and your artistic goals. Many novels combine elements from different structural approaches.
            </p>
            
            <TipBox title="Finding Your Structure">
              <p>
                If you're unsure which structure works best for your novel:
              </p>
              <ul className="list-disc pl-5 space-y-1 mt-2">
                <li>Analyze the structure of novels similar to yours that you admire</li>
                <li>Experiment with outlining your story using different structural frameworks</li>
                <li>Consider which approach best serves your specific story and themes</li>
                <li>Remember that structure should enhance your story, not constrain it</li>
                <li>Be willing to adapt your structure as your story develops</li>
              </ul>
            </TipBox>
          </Section>
          
          <Section title="Plot Development">
            <p>
              Plot is the sequence of events that make up your story. Effective plot development creates a compelling chain of cause and effect that feels both surprising and inevitable.
            </p>
            
            <h3 className="text-xl font-semibold mt-6 mb-3">The Elements of Plot</h3>
            
            <p>
              A well-developed plot includes:
            </p>
            
            <ul className="list-disc pl-6 space-y-2 my-4">
              <li>
                <strong>Conflict:</strong> The central problem or struggle that drives the story.
              </li>
              <li>
                <strong>Complications:</strong> Obstacles and challenges that make resolving the conflict difficult.
              </li>
              <li>
                <strong>Stakes:</strong> What the protagonist stands to gain or lose.
              </li>
              <li>
                <strong>Causality:</strong> Events that logically follow from previous events and character decisions.
              </li>
              <li>
                <strong>Turning points:</strong> Moments that significantly change the direction of the story.
              </li>
              <li>
                <strong>Resolution:</strong> How the conflict is ultimately addressed (not necessarily solved).
              </li>
            </ul>
            
            <h3 className="text-xl font-semibold mt-6 mb-3">Types of Conflict</h3>
            
            <p>
              Conflict is the engine of plot. Consider these different types of conflict for your novel:
            </p>
            
            <ul className="list-disc pl-6 space-y-2 my-4">
              <li>
                <strong>Character vs. character:</strong> Conflict between the protagonist and another person.
              </li>
              <li>
                <strong>Character vs. self:</strong> Internal struggle within the protagonist.
              </li>
              <li>
                <strong>Character vs. society:</strong> Conflict with social norms, institutions, or cultural expectations.
              </li>
              <li>
                <strong>Character vs. nature:</strong> Struggle against natural forces or environments.
              </li>
              <li>
                <strong>Character vs. technology:</strong> Conflict with artificial systems or creations.
              </li>
              <li>
                <strong>Character vs. supernatural:</strong> Struggle against mystical or otherworldly forces.
              </li>
              <li>
                <strong>Character vs. fate:</strong> Conflict with destiny or predetermined outcomes.
              </li>
            </ul>
            
            <p>
              Most novels contain multiple types of conflict, with one serving as the primary driving force.
            </p>
            
            <h3 className="text-xl font-semibold mt-6 mb-3">Plot Development Techniques</h3>
            
            <p>
              These approaches can help you develop a compelling plot:
            </p>
            
            <h4 className="text-lg font-medium mt-4 mb-2">1. Goal-Oriented Plotting</h4>
            
            <p>
              Start with your protagonist's goal and then:
            </p>
            
            <ul className="list-disc pl-6 space-y-1 my-2">
              <li>Identify what prevents them from achieving it immediately</li>
              <li>Create a series of attempts to overcome these obstacles</li>
              <li>Escalate the difficulty of each attempt</li>
              <li>Develop complications that force the character to adapt</li>
              <li>Lead to a final confrontation with the core obstacle</li>
            </ul>
            
            <h4 className="text-lg font-medium mt-4 mb-2">2. Conflict-Based Plotting</h4>
            
            <p>
              Begin with a central conflict and then:
            </p>
            
            <ul className="list-disc pl-6 space-y-1 my-2">
              <li>Establish what's at stake for the characters involved</li>
              <li>Develop how the conflict affects different aspects of the story world</li>
              <li>Create escalating confrontations related to the conflict</li>
              <li>Show how the conflict transforms the characters</li>
              <li>Resolve the conflict in a way that reflects this transformation</li>
            </ul>
            
            <h4 className="text-lg font-medium mt-4 mb-2">3. Character-Driven Plotting</h4>
            
            <p>
              Focus on character development and then:
            </p>
            
            <ul className="list-disc pl-6 space-y-1 my-2">
              <li>Identify the character's internal need or flaw</li>
              <li>Create situations that force them to confront this need or flaw</li>
              <li>Develop relationships that challenge or support their growth</li>
              <li>Build toward a moment of truth where they must change or fail</li>
              <li>Show the consequences of their choice</li>
            </ul>
            
            <Exercise title="Plot Development Exercise">
              <p>Take your central conflict and develop it by answering these questions:</p>
              <ol className="list-decimal pl-6 space-y-1 mt-2">
                <li>What does your protagonist want? What happens if they don't get it?</li>
                <li>What is the first major obstacle they encounter? How do they respond?</li>
                <li>What unexpected complication makes their situation worse?</li>
                <li>What is the lowest point for your protagonist? What do they lose or risk losing?</li>
                <li>What final challenge must they overcome to resolve the conflict?</li>
                <li>How are they changed by this journey?</li>
              </ol>
              <p className="mt-3">
                Use your answers to sketch a basic plot outline for your novel.
              </p>
            </Exercise>
          </Section>
          
          <Section title="Story Arcs and Narrative Shapes">
            <p>
              A story arc traces the trajectory of your narrative from beginning to end. Understanding different arc patterns helps you create a satisfying emotional journey for your readers.
            </p>
            
            <h3 className="text-xl font-semibold mt-6 mb-3">Common Narrative Shapes</h3>
            
            <p>
              Stories tend to follow certain patterns or shapes:
            </p>
            
            <ul className="list-disc pl-6 space-y-2 my-4">
              <li>
                <strong>Rising action:</strong> Steady escalation of tension toward a climax, followed by a brief resolution (the classic arc).
              </li>
              <li>
                <strong>Mountain:</strong> Gradual build to a central climax, followed by a substantial falling action and resolution.
              </li>
              <li>
                <strong>Roller coaster:</strong> Multiple rises and falls of tension throughout the narrative.
              </li>
              <li>
                <strong>Circular:</strong> Ending returns to the beginning but with new perspective or understanding.
              </li>
              <li>
                <strong>Spiral:</strong> Revisiting similar situations or themes at deeper levels of complexity.
              </li>
              <li>
                <strong>Branching:</strong> Multiple storylines that develop in parallel and may or may not converge.
              </li>
            </ul>
            
            <p>
              The shape you choose influences the emotional experience of your readers and should align with your story's themes and purpose.
            </p>
            
            <Quote 
              text="The shape of a story is as important as its content. It's the difference between a roller coaster and a merry-go-round—both are rides, but they create entirely different experiences."
              author="Kurt Vonnegut"
            />
            
            <h3 className="text-xl font-semibold mt-6 mb-3">Multiple Arcs in Novels</h3>
            
            <p>
              Most novels contain several interconnected arcs:
            </p>
            
            <ul className="list-disc pl-6 space-y-2 my-4">
              <li>
                <strong>Main plot arc:</strong> The primary storyline that spans the entire novel.
              </li>
              <li>
                <strong>Subplot arcs:</strong> Secondary storylines that develop alongside the main plot.
              </li>
              <li>
                <strong>Character arcs:</strong> The internal journeys of your protagonist and other characters.
              </li>
              <li>
                <strong>Thematic arcs:</strong> The development and exploration of your novel's central ideas.
              </li>
              <li>
                <strong>Emotional arcs:</strong> The changing emotional experience you create for your readers.
              </li>
            </ul>
            
            <p>
              These arcs should be interwoven and mutually reinforcing, with key moments often affecting multiple arcs simultaneously.
            </p>
            
            <TipBox title="Arc Mapping">
              <p>
                Create a visual map of your novel's arcs by:
              </p>
              <ul className="list-disc pl-5 space-y-1 mt-2">
                <li>Drawing a horizontal line representing the timeline of your novel</li>
                <li>Plotting the main events of your story along this timeline</li>
                <li>Drawing curves above the line to show rising tension and below to show falling tension</li>
                <li>Using different colors to represent different arcs (main plot, subplots, character arcs)</li>
                <li>Identifying where arcs intersect or influence each other</li>
                <li>Marking key emotional moments for readers</li>
              </ul>
              <p className="mt-2">
                This visual representation can help you identify pacing issues, ensure all arcs reach satisfying conclusions, and create a balanced narrative structure.
              </p>
            </TipBox>
          </Section>
          
          <Section title="Scene Construction">
            <p>
              Scenes are the building blocks of your novel. Each scene should advance the plot, develop characters, or preferably both, while creating a vivid experience for the reader.
            </p>
            
            <h3 className="text-xl font-semibold mt-6 mb-3">Scene Elements</h3>
            
            <p>
              Effective scenes typically contain these elements:
            </p>
            
            <ul className="list-disc pl-6 space-y-2 my-4">
              <li>
                <strong>Goal:</strong> What the viewpoint character wants to accomplish in this scene.
              </li>
              <li>
                <strong>Conflict:</strong> The obstacle or opposition that creates tension.
              </li>
              <li>
                <strong>Stakes:</strong> What the character stands to gain or lose.
              </li>
              <li>
                <strong>Disaster or outcome:</strong> The result of the character's attempt to achieve their goal.
              </li>
              <li>
                <strong>Emotional change:</strong> How the character's emotional state shifts during the scene.
              </li>
              <li>
                <strong>Story advancement:</strong> How the scene moves the larger narrative forward.
              </li>
            </ul>
            
            <h3 className="text-xl font-semibold mt-6 mb-3">Scene Structure</h3>
            
            <p>
              Most scenes follow this basic structure:
            </p>
            
            <ol className="list-decimal pl-6 space-y-2 my-4">
              <li>
                <strong>Entry point:</strong> How you bring readers into the scene, establishing context and drawing interest.
              </li>
              <li>
                <strong>Development:</strong> The unfolding action or interaction that builds toward the scene's purpose.
              </li>
              <li>
                <strong>Turning point:</strong> A moment of change, revelation, or decision that gives the scene significance.
              </li>
              <li>
                <strong>Aftermath:</strong> The immediate consequences or reactions to what has occurred.
              </li>
              <li>
                <strong>Transition:</strong> How you move readers to the next scene, often with a hook or question.
              </li>
            </ol>
            
            <h3 className="text-xl font-semibold mt-6 mb-3">Scene Types</h3>
            
            <p>
              Different scenes serve different functions in your novel:
            </p>
            
            <ul className="list-disc pl-6 space-y-2 my-4">
              <li>
                <strong>Action scenes:</strong> Focus on physical activity and external conflict.
              </li>
              <li>
                <strong>Reaction scenes:</strong> Show characters processing and responding to previous events.
              </li>
              <li>
                <strong>Dialogue scenes:</strong> Emphasize conversation and interpersonal dynamics.
              </li>
              <li>
                <strong>Exposition scenes:</strong> Provide necessary background information or explanation.
              </li>
              <li>
                <strong>Contemplation scenes:</strong> Explore a character's internal thoughts and feelings.
              </li>
              <li>
                <strong>Transition scenes:</strong> Bridge gaps in time or location between major events.
              </li>
            </ul>
            
            <p>
              A well-constructed novel balances these different scene types to create rhythm and maintain reader engagement.
            </p>
            
            <Exercise title="Scene Analysis and Construction">
              <p>Choose an important scene from your novel and analyze or develop it by answering:</p>
              <ol className="list-decimal pl-6 space-y-1 mt-2">
                <li>What is the viewpoint character's goal in this scene?</li>
                <li>What conflict or obstacle stands in their way?</li>
                <li>What are the stakes? What happens if they fail?</li>
                <li>How does the character approach the conflict?</li>
                <li>What is the outcome or disaster that results?</li>
                <li>How does this scene change the character emotionally?</li>
                <li>How does this scene advance the larger story?</li>
                <li>What question or hook leads into the next scene?</li>
              </ol>
              <p className="mt-3">
                Use your answers to revise an existing scene or outline a new one.
              </p>
            </Exercise>
          </Section>
          
          <Section title="Pacing and Rhythm">
            <p>
              Pacing refers to the speed at which your story unfolds. Effective pacing creates a rhythm that keeps readers engaged while providing appropriate emphasis for different story elements.
            </p>
            
            <h3 className="text-xl font-semibold mt-6 mb-3">The Importance of Varied Pacing</h3>
            
            <p>
              Varied pacing serves several crucial functions:
            </p>
            
            <ul className="list-disc pl-6 space-y-2 my-4">
              <li>
                <strong>Creates emotional rhythm:</strong> Alternating between tension and release prevents emotional fatigue.
              </li>
              <li>
                <strong>Emphasizes important moments:</strong> Slowing down for significant scenes gives them greater impact.
              </li>
              <li>
                <strong>Maintains reader interest:</strong> Changing pace prevents monotony and keeps readers engaged.
              </li>
              <li>
                <strong>Controls information flow:</strong> Pacing determines how quickly readers receive and process information.
              </li>
              <li>
                <strong>Establishes tone:</strong> The pace of your prose contributes to the overall feeling of your novel.
              </li>
            </ul>
            
            <h3 className="text-xl font-semibold mt-6 mb-3">Controlling Pace</h3>
            
            <p>
              You can adjust pacing through various techniques:
            </p>
            
            <h4 className="text-lg font-medium mt-4 mb-2">To Speed Up Pace:</h4>
            
            <ul className="list-disc pl-6 space-y-1 my-2">
              <li>Use shorter sentences, paragraphs, and chapters</li>
              <li>Focus on action and dialogue over description</li>
              <li>Increase conflict and tension</li>
              <li>Limit introspection and backstory</li>
              <li>Use more direct, concise language</li>
              <li>Summarize less important events or time periods</li>
            </ul>
            
            <h4 className="text-lg font-medium mt-4 mb-2">To Slow Down Pace:</h4>
            
            <ul className="list-disc pl-6 space-y-1 my-2">
              <li>Use longer, more complex sentences and paragraphs</li>
              <li>Include more sensory details and description</li>
              <li>Explore character thoughts and feelings</li>
              <li>Develop dialogue with subtext and nuance</li>
              <li>Insert flashbacks or relevant backstory</li>
              <li>Expand important moments with beat-by-beat narration</li>
            </ul>
            
            <Quote 
              text="Pacing is about controlling time—compressing it when readers need to move quickly and expanding it when they need to savor a moment."
              author="Donald Maass"
            />
            
            <h3 className="text-xl font-semibold mt-6 mb-3">Common Pacing Problems</h3>
            
            <p>
              Watch for these pacing issues in your novel:
            </p>
            
            <ul className="list-disc pl-6 space-y-2 my-4">
              <li>
                <strong>Sagging middle:</strong> Loss of momentum in the middle sections of your novel.
              </li>
              <li>
                <strong>Rush to resolution:</strong> Hurrying through the climax and resolution after a well-paced build-up.
              </li>
              <li>
                <strong>Information dumps:</strong> Slowing pace with large blocks of exposition or backstory.
              </li>
              <li>
                <strong>Repetitive tension:</strong> Creating similar high-tension scenes without relief.
              </li>
              <li>
                <strong>Unnecessary detours:</strong> Subplots or scenes that don't advance the main story.
              </li>
              <li>
                <strong>Inconsistent rhythm:</strong> Jarring shifts in pace without purpose.
              </li>
            </ul>
            
            <TipBox title="Pacing Audit">
              <p>
                Evaluate your novel's pacing by:
              </p>
              <ul className="list-disc pl-5 space-y-1 mt-2">
                <li>Creating a chapter-by-chapter summary noting the primary purpose and pace of each</li>
                <li>Identifying the emotional highs and lows throughout your manuscript</li>
                <li>Marking sections where readers might get bored or overwhelmed</li>
                <li>Ensuring important moments receive appropriate emphasis through pacing</li>
                <li>Checking that fast-paced and slower-paced sections alternate effectively</li>
                <li>Verifying that your pacing aligns with genre expectations</li>
              </ul>
            </TipBox>
            
            <p className="mt-4">
              In the next section, we'll explore dialogue and voice—creating authentic character speech and developing your unique authorial style.
            </p>
          </Section>
        </div>
        
        <div className="lg:col-span-1">
          <Sidebar links={sidebarLinks} />
        </div>
      </div>
    </Layout>
  );
}
